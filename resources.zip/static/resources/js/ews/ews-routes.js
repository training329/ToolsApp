
App.config(['$stateProvider','$urlRouterProvider','$httpProvider' ,'$provide', '$injector', 'IdleProvider', 'KeepaliveProvider', function ($stateProvider,$urlRouterProvider,$httpProvider, $provide,$injector, IdleProvider, KeepaliveProvider) {
	 $httpProvider.defaults.cache = false;
	 	
	 	// Configure Client session
	 	IdleProvider.idle(28*60); // in seconds
	    IdleProvider.timeout(60); // in seconds
	    IdleProvider.interrupt("keydown DOMMouseScroll mousewheel mousedown")
	    KeepaliveProvider.http('/ews/heartBeat')
	    KeepaliveProvider.interval(10*60); // in seconds
        IdleProvider.windowInterrupt('focus');
        
	    if (!$httpProvider.defaults.headers.get) {
	      $httpProvider.defaults.headers.get = {};
	    }
	    // disable IE ajax request caching
	    $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
	    //.....here proceed with your routes
	    $httpProvider.interceptors.push('APIInterceptor');
	  $stateProvider
	  	    .state('exceptions', {
	    	 url: '/exceptions',
	          templateUrl: '/ews/html/partials/exceptions/layout.html',
	          controller: ExceptionController,		      
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }

	    }).state('clientoverview', {
	    	 url: '/clientoverview',
	    	 params: {
	    		cobdate:'',
	    		client:'',
	    		fund:'',
	    	 },
	          templateUrl: '/ews/html/partials/clientoverview/layout.html',
	          controller: ClientOverviewController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }

	    }).state('coverage', {
	    	 url: '/coverage',
	          templateUrl: '/ews/html/partials/coverage/layout.html',
	          controller: CoverageController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }

	    }).state('admin', {
	    	 url: '/admin',
	          templateUrl: '/ews/html/partials/admin/layout.html',
	          controller: adminController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }

	    }).state('manageuser', {
	    	 url: '/admin/edit/:id',
	          templateUrl: '/ews/html/partials/admin/edit.html',
	          controller: adminmanageController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }
		   
	    }).state('addexception', {
	    	 url: '/exceptions/add',
	          templateUrl: '/ews/html/partials/exceptions/add.html',
	          controller: ExceptionAddController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }
	    }).state('editexception', {
	    	 url: '/exceptions/edit/:id',
	          templateUrl: '/ews/html/partials/exceptions/edit.html',
	          controller: ExceptionEditController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }
		 
	    }).state('login', {
	    	 url: '/',
	          templateUrl: '/ews/html/partials/login/layout.html',
	          controller: LoginController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	            	  if(authService.user && authService.user.isAuthenticated == true){
	                	  return $q.reject({authorized:true});
	                  }else{
	                	  return authService.user;
	                  }
	              }]
	          },
	         
	    })
	    .state('exceptionsummary', {
	    	 url: '/exceptionsummary',
	          templateUrl: '/ews/html/partials/exceptionsummary/layout.html',
	          controller: ExceptionSummaryController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }

	    }) .state('editexceptionsummary', {
	    	 url: '/exceptionsummary/edit/:id',
	          templateUrl: '/ews/html/partials/exceptionsummary/viewsummary.html',
	          controller: ExceptionSummaryViewController,
	          resolve:{
	              user:['authService','$q',function(authService,$q){
	                  return authService.user || $q.reject({unAuthorized:true});
	              }]
	          }
	    })
	     
	    $urlRouterProvider.otherwise('/');

	 // Angular provides a built-in global exception handling service called $exceptionHandler.
 	 // Any uncaught exception is delegated to this service. This service only catches exceptions, not communication errors (such as 404 not found) or syntax errors.
	  $provide.decorator("$exceptionHandler", 
			  ["$delegate", "$injector", 
			   		function($delegate, $injector){
				  		return function(exception, cause) {
				  			 var $rootScope = $injector.get("$rootScope");
				  			var displayMessage =  "Message: "+ exception.message +" \nApplication may not behave properly. Please contact the Dev Team!";
				  			$rootScope.$broadcast('globalError', {message: displayMessage, exception: exception, cause: cause}); 
				  			$delegate(exception, cause);
				  			
				  		}
			  		}
			   ]);
}]);
	    
