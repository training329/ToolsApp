/**
 * added by aw11769
 */
var ExceptionSummaryController = function ($scope, $state, $cookies, $location,
                                           $window, $rootScope, $http, $filter, NgTableParams, blockUI, toastr, user,
                                           authService) {
    $scope.FlaggedExceptionListOrginal = [];
    $scope.FlaggedExceptionList = [];
    $scope.FlaggedExceptionList1 = [];
    $scope.FlaggedExceptionList2 = [];
    $scope.historyList = [];
    $scope.showCharts = 2;
    $scope.Searchterm = '';

    var result = user;
    $scope.currentUser = result.name;
    $scope.soeid = result.soeid;
    $scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;

    $scope.selectedExceptionId = {};
    $scope.selectedExceptionList = []; 
    $scope.selectedExceptionIdList = [];  
    $scope.selectedExceptionIdNActivityId = [];
    $scope.errorMsg = '';  
    $scope.successMsg = '';  
    $scope.partialSuccessMsg = '';
    $scope.bulkUpdateCompleted = false;
    $scope.myAlertsPageNum = '';
    $scope.alertsPageNum = '';
    $scope.myAlertsCheckbox = {};
    $scope.alertsCheckbox = {};
    $scope.myAlertsSorting = {};
    $scope.alertsSorting = {};
  

    if (angular.isDefined($scope.files)) {
        $('#exceptionFile').val('');
        $scope.files = [];
    }
    
    angular.isUndefinedOrNull = function(val) {
        return angular.isUndefined(val) || val === null || val == '';
    }
    
    angular.validate = function(bulkExceptionmodel) {
        if (angular.isUndefinedOrNull(bulkExceptionmodel.status) && angular.isUndefinedOrNull(bulkExceptionmodel.exception_owner)) {
            $scope.errorMsg = 'Please select either Status or Alert Owner';
            return false;
        }
        if (angular.isUndefinedOrNull(bulkExceptionmodel.comment)) {
            $scope.errorMsg = 'Please enter Alert Comment';
            return false;
        }
        return true;
    }

    $scope.countChecked = function () {
        var count = 0;
        angular.forEach($scope.selectedExceptionId, function (key) {
            if (count == 0 && key) {
                count++;
                return count;
            }
        });
        return count;
    };
    
    var updateSelected = function(action, id) {
  	  if (action === 'add') {
  		  $scope.selectedExceptionId[id] = true;
  	  }
  	  if (action === 'remove') {
  		delete $scope.selectedExceptionId[id];
  	  } 
  	};
      
  	$scope.selectAll = function($event, tab) {
  	  var checkbox = $event.target;
  	  var action = (checkbox.checked ? 'add' : 'remove');
  	  
  	  if(tab == 'Alerts') {
  		  for ( var i = 0; i < $scope.data.length; i++) {
  		    var entity = $scope.data[i];
  		    updateSelected(action, entity.exception_id);
  		  }
  	  } else {
  		  for ( var j = 0; j < $scope.data1.length; j++) {
  		    var entity1 = $scope.data1[j];
  		    updateSelected(action, entity1.exception_id);
  		  }
  	  }   
  	};

    $scope.bulkUpdate = function () {
        $scope.selectedExceptionIdNActivityId = [];
        $scope.selectedExceptionList = [];
        $scope.selectedExceptionIdList = [];
        $scope.result = [];
        $scope.bulkExceptionmodel = {};
        $scope.errorMsg = '';
        $scope.successMsg = '';
        $scope.partialSuccessMsg = '';
        $scope.bulkUpdateCompleted = false;
        $scope.isChange = false;

        if (angular.isDefined($scope.files)) {
            $('#exceptionFile').val('');
            $scope.files = [];
        }

        if (angular.isDefined($scope.selectedExceptionId)) {
            angular.forEach($scope.selectedExceptionId, function (key, value) {
                if (key) {
                    $scope.result = _.filter($scope.FlaggedExceptionListOrginal,
                        function (val) {
                            return val.exception_id == value
                        });
                    $scope.result = _.uniq($scope.result, 'exception_id');
                    $scope.result = _.sortBy($scope.result,
                        function (val) {
                            return val.exception_id
                        });
                    if ($scope.result) {
                        $scope.getStatusType($scope.result[0].status);
                        $scope.result[0].alert_status = $scope.status[0].text;

                        var keyValue = value + ":" + $scope.result[0].exception_activity_id;
                        $scope.selectedExceptionIdNActivityId.push(keyValue);

                        $scope.selectedExceptionIdList.push(value);
                        $scope.selectedExceptionList.push($scope.result[0]);
                    }
                }
            });
            $scope.isSaved = false;
            $('#bulkUpdateModal').modal('show');
        }
    };
    
    $scope.$watch('bulkExceptionmodel', function (entity) {
    	if(!angular.isUndefinedOrNull(entity)) {
    		$scope.checkDataModification(entity);
    	}
    }, true);
    
    $scope.checkDataModification = function (entity) {
        if (!angular.isUndefinedOrNull(entity.status)  || !angular.isUndefinedOrNull(entity.exception_owner) || 
        	!angular.isUndefinedOrNull(entity.comment) || (!angular.isUndefinedOrNull($scope.files) && $scope.files.length > 0)) {
        	if (!angular.isUndefinedOrNull(entity.status) && angular.equals("3", entity.status) 
        			&& angular.isUndefinedOrNull(entity.comment)) {
        		$scope.isChange = false;
        		$scope.errorMsg = 'Please enter Alert Comment';
        	} else {
        		$scope.isChange = true;
        		$scope.errorMsg = '';
        	}	
        } else {
        	$scope.isChange = false;
        }
    };

    $scope.resetSelectedExceptionIds = function () {
        $scope.selectedExceptionId = {};
        $scope.myAlertsCheckbox = {};
        $scope.alertsCheckbox = {};
    };
    
    $scope.renderChart = function () {
    	if($scope.showCharts == 1){
        	$scope.CalculateChartData($scope.FlaggedExceptionFilteredList);
        } else if($scope.showCharts == 2){
        	$scope.CalculateChartData($scope.FlaggedExceptionFilteredList1);
        } 
    };

    $scope.removeException = function (index, removedExceptionId, removedActivityId) {
    	delete $scope.selectedExceptionId[removedExceptionId];
        $scope.selectedExceptionIdList.splice(index, 1);
        $scope.selectedExceptionList.splice(index, 1);

        var keyValueIndexStr = removedExceptionId + ":" + removedActivityId;
        var keyValueIndex = $scope.selectedExceptionIdNActivityId.indexOf(keyValueIndexStr);
        $scope.selectedExceptionIdNActivityId.splice(keyValueIndex, 1);
        $("#row-" + removedExceptionId).hide('slow');
        $("#dataCheckbox-" + removedExceptionId).attr('checked', false);
    };


    $scope.bulkUpdateFlaggedExceptionRule = function (bulkExceptionmodel) {
    	console.time("scope.bulkUpdateFlaggedExceptionRule: GET");
        $scope.bulkUpdateCompleted = false;
        bulkExceptionmodel.exception_id_list = $scope.selectedExceptionIdNActivityId.join();
        bulkExceptionmodel.exception_ids = $scope.selectedExceptionIdList.join();
        bulkExceptionmodel.selectedExceptionIdList = $scope.selectedExceptionIdList;
        
        /*if(!angular.validate(bulkExceptionmodel)) {
        	return false;
        }*/
       
        var request = {
            method: 'POST',
            url: '/ews/exceptionsummary/bulkUpdate',
            headers: { 
            	'Content-Type': undefined  
            },
            transformRequest: function (data) {
                var formData = new FormData();
                formData.append('bulkExceptionmodel', new Blob([angular.toJson(bulkExceptionmodel)], {
                    type: "application/json"
                }));
                angular.forEach(data.file, function (file) {
                    formData.append('file', file);
                });
                return formData;
            },
            data: {	
        		data: bulkExceptionmodel, 
        		file: $scope.files 
            }
        };
        $http(request)
            .success(
                function (data) {
                    console.timeEnd("scope.bulkUpdateFlaggedExceptionRule: GET");
                    console.time("scope.bulkUpdateFlaggedExceptionRule: SCREEN");
                    $scope.errorMsg = '';
                    $scope.successMsg = '';
                    $scope.partialSuccessMsg = '';
                    $scope.bulkUpdateCompleted = true;
                    if (!data[0].error) {
                        $scope.tempSelectedExceptionList = [];
                        var totalCount = 0;
                        var errorCount = 0;
                        var successCount = 0;
                        
                        angular.forEach(data, function (bulkExceptionRes) {
                            if (bulkExceptionRes) {
                                totalCount++;
                                $scope.tempResult = _.filter($scope.selectedExceptionList, function (val) { 
                                	return val.exception_id == bulkExceptionRes.exception_id 
                                });
                                var resultObj = $scope.tempResult[0];
                                var statusValue = bulkExceptionRes.operation_status_value;
                                if (statusValue == 1) {
                                    successCount++;
                                    resultObj.operationSuccess = true;
                                } else {
                                    errorCount++;
                                    resultObj.operationSuccess = false;
                                }
                                if (bulkExceptionRes.status != undefined || bulkExceptionRes.status != null) {
                                    $scope.getStatusType(bulkExceptionRes.status);
                                    resultObj.alert_status = $scope.status[0].text;
                                } else {
                                    $scope.getStatusType(resultObj.status);
                                    resultObj.alert_status = $scope.status[0].text;
                                }
                                resultObj.operation_status = bulkExceptionRes.operation_status;
                                resultObj.updatedby = bulkExceptionRes.updatedby;
                                $scope.tempSelectedExceptionList.push(resultObj);
                            }
                        });
                        
                        $scope.selectedExceptionList = [];
                        $scope.tempSelectedExceptionList = _.uniq($scope.tempSelectedExceptionList, 'exception_id');
                        $scope.tempSelectedExceptionList = _.sortBy($scope.tempSelectedExceptionList, function (val) {
                        	return val.exception_id 
                        });
                        $scope.selectedExceptionList = angular.copy($scope.tempSelectedExceptionList);
                        var bulkExceptionResponse = data[0];
                        $scope.bulkExceptionmodel.status = bulkExceptionResponse.status;
                        $scope.bulkExceptionmodel.exception_owner = bulkExceptionResponse.exception_owner;
                        $scope.bulkExceptionmodel.comment = bulkExceptionResponse.comment;
                        
                        if (successCount == totalCount) {
                            $scope.successMsg = 'Bulk update successfully completed.';
                            $scope.resetSelectedExceptionIds();
                            $scope.tableParams.page(1);
                            $scope.tableParams1.page(1);
                            $scope.tableParams2.page(1);
                            $scope.getFlaggedExceptionList();
                            toastr.success($scope.successMsg);
                        } else if (errorCount == totalCount) {
                            $scope.errorMsg = 'Bulk update not successful due to client coverage. Please see Operation Status message for each alert';
                            toastr.error($scope.errorMsg);
                        } else {
                            $scope.partialSuccessMsg = 'Bulk update partially successful due to client coverage. Please see Operation Status message for each alert and in Operation Status if alert already updated by other user';
                            $scope.resetSelectedExceptionIds();
                            $scope.tableParams.page(1);
                            $scope.tableParams1.page(1);
                            $scope.tableParams2.page(1);
                            $scope.getFlaggedExceptionList();
                            toastr.error($scope.partialSuccessMsg);
                        }
                        
                        $scope.isSaved = true;
                    } else {
                        $scope.isSaved = true;
                        $scope.successMsg = '';
                        $scope.partialSuccessMsg = '';
                        $scope.errorMsg = data[0].errorMessage;
                        toastr.error(data[0].errorMessage, 'Error');
                    }
                    console.timeEnd("scope.bulkUpdateFlaggedExceptionRule: SCREEN");
                }).error(function () {
                	toastr.error('Error while updating alert. Please try again or contact AQUA RACE support', 'Error');
                });
    };

    $scope.uploadFile = function (files) {
        $scope.$apply(function ($scope) {
            $scope.files = files;
            $scope.checkDataModification(files);
        });
    };

    $scope.getMasters = function () {
        console.time("scope.getMasters: GET");
        $http.get('/ews/exceptionrule/getmaster/exception_status', {globalErrorsInterceptor:true})
        .success(
            function (data) {
                console.timeEnd("scope.getMasters: GET");
                console.time("scope.getMasters: SCREEN");

                $scope.statusTypes = data;
                console.timeEnd("scope.getMasters: SCREEN");
            });
    };

    $scope.getAllUsers = function () {
        console.time("scope.getAllUsers: GET");
        $http.get('/ews/exceptionsummary/search/', {globalErrorsInterceptor:true})
            .success(
            		function (response) {
                        console.timeEnd("scope.getAllUsers: GET");
                        console.time("scope.getAllUsers: SCREEN");

                $scope.users = response;
                console.timeEnd("scope.getAllUsers: SCREEN");
            });
    };

    $scope.formatLabel = function (model) {
        if (model != undefined) {
            var filteredGoal = _.filter($scope.users, function (num) {
                return $filter('lowercase')(num.value) == $filter(
                        'lowercase')(model);
            });
            if (filteredGoal.length > 0) {
                return filteredGoal[0].text;
            } else {
                return model;
            }
        } else {
            return ''
        }
    };

    $scope.getStatusType = function (statusValue) {
        $scope.status = '';
        $scope.status = _.filter($scope.statusTypes,
            function (val) {
                return val.value == statusValue
            });
        return $scope.status;
    };

    $scope.onStatusSelect = function (statusValue) {
        if (angular.isDefined(statusValue) && statusValue == '3') {
            if (angular.isDefined($scope.bulkExceptionmodel.exception_owner))
                $scope.bulkExceptionmodel.exception_owner = '';
        }
    };

    $scope.showPriority = function (agestring, priority, color) {
        var age = parseInt(agestring);
        switch (color) {
            case "RED":
                if (priority === 'High') {
                    return true;
                } else if (priority === 'Medium') {
                    return age >= 5;
                } else if (priority === 'Low') {
                    return age > 5;
                } else {
                    return false;
                }

                break;
            case "GREEN":
                if (priority === 'Medium') {
                    return age <= 1;
                } else if (priority === 'Low') {
                    return age <= 2;
                } else {
                    return false;
                }
                break;
            case "YELLOW":
                if (priority === 'Medium') {
                    return (age >= 2 && age <= 4);
                } else if (priority === 'Low') {
                    return (age >= 3 && age <= 5);
                } else {
                    return false;
                }
                break;
        }

    };
    $scope.soeidFilter = function (item) {
        var currentUser = $scope.currentUser;
        return item.exception_owner === currentUser;
    };

    $scope.plotchart1 = function (chartcatagories, chartopen, chartresolved,
                                  underreview, reassigned) {
        console.time("plotchart1");

        $('#chart1')
            .highcharts(
                {
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: 'Alert Status by Date'
                        // ,align: 'left'
                    },

                    subtitle: {
                        text: '',
                        x: -20
                    },
                    credits: {
                        enabled: false
                    },
                    xAxis: {
                        categories: chartcatagories,
                        labels: {
                            rotation: -15
                        }

                    },
                    yAxis: {
                        title: {
                            text: 'Alert Count'
                        },
                        min: 0,
                        enabled: true,
                        style: {
                            fontWeight: 'bold',
                            color: (Highcharts.theme && Highcharts.theme.textColor)
                            || 'gray'
                        }

                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px"><b>{point.key}</b></span><table>',
                        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>'
                        + '<td style="padding:0"><b>{point.y}</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },
                    legend: {
                        align: 'center',
                        x: -30,
                        verticalAlign: 'bottom',
                        y: 10,
                        floating: true,
                        // backgroundColor: (Highcharts.theme &&
                        // Highcharts.theme.background2) || 'white',
                        // borderColor: '#CCC',
                        // borderWidth: 1,
                        shadow: false
                    },
                    plotOptions: {
                        column: {
                            stacking: 'normal',
                            dataLabels: {
                                enabled: true,
                                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor)
                                || 'white',
                                style: {
                                    textShadow: '0 0 3px black'
                                },
                                formatter: function () {
                                    if (this.y > 0)
                                        return this.y;
                                }

                            }
                        }
                    },
                    series: [{
                        name: 'Resolved',
                        data: chartresolved,
                        color: '#969696'
                    }, {
                        name: 'Under Review',
                        data: underreview,
                        color: '#90CCEF'
                    }, {
                        name: 'Open',
                        data: chartopen,
                        color: '#4E728F'
                    }]
                });
        console.timeEnd("plotchart1");
    };
    $scope.getExceptionChartData = function () {
    	console.time("scope.getExceptionChartData: GET");
        var chartcatagories = [];
        var chartexceptions = [];
        var chartresolved = [];
        var chartopen = [];
        var underreview = [];
        var reassigned = [];
        $http.get('/ews/exceptionsummary/exceptionstatuschart/', {globalErrorsInterceptor:true}).success(
            function (data) {
                console.timeEnd("scope.getExceptionChartData: GET");
                console.time("scope.getExceptionChartData: SCREEN");
                var chartData = _.sortBy(data, function (val) {
                    return val.exception_id
                });
                angular.forEach(chartData, function (node, index) {
                    chartcatagories.push(node.date);
                    chartexceptions.push(node.exceptions);
                    chartresolved.push(node.resolved);
                    chartopen.push(node.open);
                    underreview.push(node.review);
                    reassigned.push(node.reassigned)
                });
                $scope.plotchart1(chartcatagories, chartopen,
                    chartresolved, underreview.reassigned);
                console.timeEnd("scope.getExceptionChartData: SCREEN");
            });
        //TODO ADD ERROR CALL
        
    };
    // $scope.getExceptionChartData();
    $scope.statusFilter = function (item) {
        //TODO: Verify that currentUser variable is used anywere else?
        //var currentUser = $scope.currentUser;
        return item.status === '3';
    };
    $scope.logout = function () {
        // $http.get('/ews/sso/logout').success(function(data) {
        // $cookies.currentUser = null;
        // $state.go('login');
        // });
        authService.logout().then(function (data) {
            $state.go('login');
        })
    };
    $scope.tableParams = new NgTableParams(
        {
            page: 1,
            count: 10,
            sorting: {
                cob_date : "desc",
                priority_id: "asc"
            }

        },
        {
            total: $scope.FlaggedExceptionList.length,
            getData: function (params) {
            	$scope.alertsPageNum = params.page();
                console.time("tableParams.getData");
                if($scope.FlaggedExceptionFilteredList){
	                $scope.filteredData = params.sorting() ? $filter('orderBy')($scope.FlaggedExceptionFilteredList, params.orderBy()) : $scope.FlaggedExceptionFilteredList;
	                params.total($scope.filteredData.length);
	                $scope.data = ($scope.filteredData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
		            if(!angular.isUndefinedOrNull($scope.alertsSorting) && !angular.equals(params.sorting(), $scope.alertsSorting)) {
			            $scope.resetSelectedExceptionIds();
		            }
		            $scope.alertsSorting = params.sorting();
	                console.timeEnd("tableParams.getData");
                return $scope.data;
                }
                return null;
            }
        });

    $scope.Searchterm = $rootScope.Searchterm1;

    $scope.applyGlobalSearch = function (term) {
        console.time("applyGlobalSearch");
        $scope.resetSelectedExceptionIds();
        $rootScope.Searchterm1 = term;
        $scope.tableParams.filter({
            $: term
        });
        $scope.tableParams1.filter({
            $: term
        });
        $scope.tableParams2.filter({
            $: term
        });
        
        if(term === ""){
        	// reset the data to original list instead of re-filtering
        	$scope.FlaggedExceptionFilteredList = $scope.FlaggedExceptionList;
            $scope.FlaggedExceptionFilteredList1 = $scope.FlaggedExceptionList1;
            $scope.FlaggedExceptionFilteredList2 = $scope.FlaggedExceptionList2;
        }else{
        	// filter the data once instead of doing it on each page
        	$scope.FlaggedExceptionFilteredList = filterData($scope.FlaggedExceptionList);
            $scope.FlaggedExceptionFilteredList1 = filterData($scope.FlaggedExceptionList1);
            $scope.FlaggedExceptionFilteredList2 = filterData($scope.FlaggedExceptionList2);
        }
        
        if($scope.showCharts == 1){
        	$scope.CalculateChartData($scope.FlaggedExceptionFilteredList);
        } else if($scope.showCharts == 2){
        	$scope.CalculateChartData($scope.FlaggedExceptionFilteredList1);
        } 
        
        console.timeEnd("applyGlobalSearch");
    };

    var filterData = function (data) {
        console.time('filterData');
        var result = data;
        if ($scope.Searchterm != null && data) {
        	var criterias  = ["client", "exception_owner_name", "exception_id", "clientTier"];
        	var term = angular.lowercase($scope.Searchterm);
        	result = data.filter(function(item){
        		var found = false;
        		angular.forEach(criterias, function (criteria, index) {
        			if(item[criteria] && (angular.lowercase(item[criteria]).toString()).indexOf(term) != -1){
        				return found = true;
        			}
        		})
        		return found;
        	});
        }
        console.timeEnd('filterData');
        return result;
    };

    $scope.CalculateChartData = function (data) {
        console.time("CalculateChartData");
        $scope.CalculateTopClientChartData(data);
        var a = [];
        var b = [];
        var c = [];
        var d = [];
        var e = [];

        var result1 = _.sortBy(data, function(val) {
			return val.exception_id
		});
        
        var result = _.chain(result1).groupBy('cob_date').map(
            function (value, key) {
                return {
                    cob_date: key,
                    status: _.countBy(value, function (obj) {
                        switch (obj.status_name) {
                            case 'Open':
                                return "open";
                                break;
                            case 'Under Review':
                                return "review";
                                break;
                            case 'Resolved':
                                return "resolved";
                                break;
                            case 'Re-Assigned':
                                return "assigned";
                                break;
                        }
                    })
                }
            }).last(5).value();
        _.each(result, function (value, key, obj) {
            a.push(value.cob_date);
            b.push('open' in value.status ? value.status.open : 0);
            c.push('review' in value.status ? value.status.review : 0);
            d.push('resolved' in value.status ? value.status.resolved : 0);
            e.push('assigned' in value.status ? value.status.assigned : 0);
        });
        $scope.plotchart1(a, b, d, c, e);
        console.timeEnd("CalculateChartData");
    };
    
    $scope.CalculateTopClientChartData = function (data) {
        console.time("CalculateTopClientChartData");
        var result = _.chain(data).groupBy('client').map(
            function (value, key) {
                return {
                    client: key,
                    status: _.countBy(value, function (obj) {
                        switch (obj.status_name) {
                            case 'Open':
                                return "open";
                            case 'Under Review':
                                return "review";
                        }
                    }),
                    total_alerts : value.length
                }
            }).value();
            
        var top5clients = _.sortBy(result, function(val) {
			return val.total_alerts
		}).reverse().slice(0, 5);
      
        $scope.getExceptionOwnerChartData(top5clients)
        console.timeEnd("CalculateTopClientChartData");
    };
    
    $scope.tableParams1 = new NgTableParams({
        page: 1,
        count: 10,
        sorting: {
        	cob_date : "desc",
            priority_id: "asc"
        }

    }, {
        total: $scope.FlaggedExceptionList1.length,
        getData: function (params) {
            console.time("tableParams1.getData");
            $scope.myAlertsPageNum = params.page();
            if($scope.FlaggedExceptionFilteredList1) {
	            $scope.filteredData1 = params.sorting() ? $filter('orderBy')($scope.FlaggedExceptionFilteredList1, params.orderBy()) : $scope.FlaggedExceptionFilteredList1;
	            params.total($scope.filteredData1.length);
	            $scope.data1 = $scope.filteredData1.slice((params.page() - 1) * params.count(), params.page() * params.count());
	            if(!angular.isUndefinedOrNull($scope.myAlertsSorting) && !angular.equals(params.sorting(), $scope.myAlertsSorting)) {
		            $scope.resetSelectedExceptionIds();
	            }
	            $scope.myAlertsSorting = params.sorting();
	            console.timeEnd("tableParams1.getData");
	            return $scope.data1;
            }
            return null
        }
    });
    $scope.tableParams2 = new NgTableParams({
        page: 1,
        count: 17,
        sorting: {
             cob_date : "desc"
        }

    }, {
        total: $scope.FlaggedExceptionList2.length,
        getData: function (params) {
            console.time("tableParams2.getData");
            if($scope.FlaggedExceptionFilteredList2){
	            $scope.filteredData2 = params.sorting() ? $filter('orderBy')($scope.FlaggedExceptionFilteredList2, params.orderBy()) : $scope.FlaggedExceptionFilteredList2;
	            params.total($scope.filteredData2.length);
	            $scope.data2 = $scope.filteredData2.slice((params.page() - 1) * params.count(), params.page() * params.count());
	            console.timeEnd("tableParams2.getData");
	            return $scope.data2;
            }
            return null;
        }
    });

    $scope.getExceptionOwnerChartData = function (data) {
        var chartcatagories = [];
        var chartdata = [];
        var review = [];
        console.time("scope.getExceptionOwnerChartData: SCREEN");

        angular.forEach(data, function (node) {
            chartcatagories.push(node.client);
            if(node.status){
            	chartdata.push('open' in node.status ? node.status.open : 0);
                review.push('review' in node.status ? node.status.review : 0);
            }
        });
        $('#chart2')
            .highcharts(
                {
                    chart: {
                        type: 'bar'
                    },
                    title: {
                        text: 'Top 5 Clients by Alert'
                        // align: 'left'
                    },
                    yAxis: {
                        title: {
                            text: 'Alert Count'
                        }
                    },
                    credits: {
                        enabled: false
                    },
                    xAxis: {
                        categories: chartcatagories
                    },
                    yAxis: {
                        allowDecimals: false,
                        title: {
                            text: null
                        }
                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px"><b>{point.key}</b></span><table>',
                        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>'
                        + '<td style="padding:0"><b>{point.y}</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },
                    legend: {

                        reversed: true,
                        // x: -30,

                        y: 10,

                        shadow: false
                    },
                    plotOptions: {
                        series: {
                            stacking: 'normal',
                            cursor: 'pointer',
                            point: {
                                events: {
                                    click: function () {
                                    	var globalSearchInput = $('#globalSearchInput');
                                    	if(globalSearchInput && this.category){
                                    		if($scope.Searchterm === this.category){
                                    			globalSearchInput.val("").trigger('change');
                                    		}else{
                                    			globalSearchInput.val(this.category).trigger('change');
                                    		}
                                    		
                                    	}
                                    }
                                }
                            }
                        }
                    },
                    series: [{
                        data: chartdata,
                        name: "Open",
                        color: '#4E728F'
                    }, {
                        name: "Under Review",
                        data: review,
                        color: '#90CCEF'
                    }
                    ]
                });
        console.timeEnd("scope.getExceptionOwnerChartData: SCREEN");
        		//TODO ADD ERROR CALL
        		
    };
    // $scope.getExceptionOwnerChartData();

    $scope.getFlaggedExceptionList = function () {
        console.time("scope.getFlaggedExceptionList: GET");
        $http
            .get('/ews/exceptionsummary/flaggedexceptionlist.json', {globalErrorsInterceptor:true})
            .success(
                function (data) {
                    console.timeEnd("scope.getFlaggedExceptionList: GET");
                    console.time("scope.getFlaggedExceptionList: SCREEN");
                    $scope.FlaggedExceptionList1 = [];
                    $scope.FlaggedExceptionList2 = [];
                    //$scope.FlaggedExceptionListOrginal = angular
                    //		.copy(data);
                    $scope.FlaggedExceptionList = _
                        .filter(
                            data,
                            function (val) {
                                return val.status_name == 'Open'
                                    || val.status_name == 'Under Review'
                            });
                    // $scope.FlaggedExceptionList=_.chain($scope.FlaggedExceptionList)
                    // .sortBy('age').reverse().value();
                    $scope.FlaggedExceptionList1 = _
                        .filter(
                            data,
                            function (val) {
                                return ($filter('lowercase')(
                                    val.exception_owner) === $filter(
                                    'lowercase')(
                                    $scope.soeid) && ((val.status_name === 'Open') || (val.status_name === 'Under Review')))
                            });
                    $scope.FlaggedExceptionList2 = _.filter(data,
                        function (val) {
                            return val.status_name == 'Resolved'
                        });
                    
                    
                    $scope.FlaggedExceptionFilteredList = filterData($scope.FlaggedExceptionList);
                    $scope.FlaggedExceptionFilteredList1 = filterData($scope.FlaggedExceptionList1);
                    $scope.FlaggedExceptionFilteredList2 = filterData($scope.FlaggedExceptionList2);
                    
                    $scope.tableParams.reload();
                    $scope.tableParams1.reload();
                    $scope.tableParams2.reload();

                    $scope.CalculateChartData($scope.FlaggedExceptionFilteredList1);
                    $scope.FlaggedExceptionListOrginal = data;
                    console.timeEnd("scope.getFlaggedExceptionList: SCREEN");
                });
        		//TODO ADD ERROR CALL
    };

    $scope.exportexcel = function () {
    	console.time("scope.exportexcel: GET");
        var Objfilter = {
            tab: $scope.showCharts,
            term: $scope.Searchterm
        };
        var config = {
            params: Objfilter,
            headers: {'Accept': 'application/json'},
            globalErrorsInterceptor:true
        };
        
        $http.get('/ews/exceptionsummary/export', config).success(
            function (data) {
                console.timeEnd("scope.exportexcel: GET");
                console.time("scope.exportexcel: SCREEN");
                console.timeEnd("scope.exportexcel: SCREEN");
            });
        	//TODO ADD ERROR CALL
    };

    $scope.getFlaggedExceptionList();
    $scope.getMasters();
    $scope.getAllUsers();
};

var ExceptionSummaryViewController = function ($scope, $state, $cookies,
                                               $stateParams, $location, $window, $rootScope, $http, $filter, user,
                                               NgTableParams, toastr, authService) {
    $scope.historyList = [];
    $scope.FlagedSecurityExceptionRule = [];
    $scope.users = [];
    //$("[data-toggle='tooltip']").tooltip();
    $scope.getColor = function (data) {
        if (data)
            return {
                backgroundColor: '#FFFF99'
            }
    };
    $scope.id = $stateParams.id;

    var result = user;// $cookies.getObject('Userinfo');
    $scope.currentUser = result.name;
    $scope.soeid = result.soeid;
    $scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;
    $scope.logout = function () {
        authService.logout().then(function (data) {
            $state.go('login');
        })
    };
    $scope.getMasters = function () {
        console.time("scope.getMasters: GET");
        $http.get('/ews/exceptionrule/getmaster/exception_status', {globalErrorsInterceptor:true}).success(
            function (data) {
                console.timeEnd("scope.getMasters: GET");
                console.time("scope.getMasters: SCREEN");
                $scope.statusTypes = data;
                console.timeEnd("scope.getMasters: SCREEN");
            });
        	//TODO ADD ERROR CALL
    };

    $scope.onSelect = function ($item, $model, $label) {
    	console.time("scope.onSelect: GET");
        $http.get('/ews/exceptionsummary/isUserUnderCoverage/' + $item.value + '/' + $scope.id, {globalErrorsInterceptor:true})
            .success(function (response) {
                console.timeEnd("scope.onSelect: GET");
                console.time("scope.onSelect: SCREEN");

                if (response) {
                    $model = $item.value;
                } else {
                    $scope.exceptionmodel.exception_owner = '';
                    toastr.error('Cannot reassign alert to new owner due to missing access role or client coverage.', 'Error');
                }
                console.timeEnd("scope.onSelect: SCREEN");
            });
        	//TODO ADD ERROR CALL

//		if(_.contains($scope.AssigneeList,$filter('lowercase')($model)))
//			{
//			$model = $item.value;
//			}else{
//				$scope.exceptionmodel.exception_owner='';
//				toastr.error('Cannot reassign alert to new owner due to missing access role or client coverage.','Error');
//			}

    };
    $scope.getSecurityAtrributs = function (key) {
        var label = "";
        switch (key) {
            case "country_of_risk_grouping":
                label = "Country Of Risk Grouping";
                break;
            case "product_grouping":
                label = "Product Grouping";
                break;
            case "sector":
                label = "Sector";
                break;
            case "marketcap":
                label = "Market Cap";
                break;
        }

        return label;
    };

    $scope.getAssigneeList = function (id) {
        console.time("scope.getAssigneeList: GET");
        $http.get('/ews/exceptionsummary/getAssigneeList/' + id, {globalErrorsInterceptor:true})
            .success(function (response) {
                console.timeEnd("scope.getAssigneeList: GET");
                console.time("scope.getAssigneeList: SCREEN");
                $scope.AssigneeList = response;
                console.timeEnd("scope.getAssigneeList: SCREEN");
            });
        	//TODO ADD ERROR CALL
    };

    $scope.formatLabel = function (model) {
        if (model != undefined) {
            var filteredGoal = _.filter($scope.users, function (num) {
                return $filter('lowercase')(num.value) == $filter(
                        'lowercase')(model);
            });
            if (filteredGoal.length > 0) {
                return filteredGoal[0].text;
            } else {
                return ($scope.exceptionmodel != null && $scope.exceptionmodel.exception_owner_name != null) ? $scope.exceptionmodel.exception_owner_name : model;
            }
        } else {
            return ''
        }
    };

    $scope.getAllUsers = function (term) {
        console.time("scope.getAllUsers: GET");
        if (term == undefined || term == "")
            return;

        $http.get('/ews/exceptionsummary/search/' + term)
            .success(function (response) {
                console.timeEnd("scope.getAllUsers: GET");
                console.time("scope.getAllUsers: SCREEN");

                $scope.users = response;
                console.timeEnd("scope.getAllUsers: SCREEN");
            });
        	//TODO ADD ERROR CALL
    };


    $scope.getMasters();
    //$scope.getAssigneeList($stateParams.id);
    $scope.oldModel = {};

    $scope.setError = "";
    $scope.getData = function (id) {
    	console.time("scope.getData: GET");
        $scope.getAllUsers($scope.id);
        $http
            .get('/ews/exceptionsummary/get/' + id)
            .success(
                function (data) {
                    console.timeEnd("scope.getData: GET");
                    console.time("scope.getData: SCREEN");
                    if (data) {
                        var filterdata = _.sortBy(data, function (val) {
                            return -val.exception_activity_id;
                        });
                        $scope.exceptionmodel = {};
                        $scope.exceptionmodel = angular.copy(filterdata[0]);
                        $scope.exceptionmodel.comment = '';
                        $scope.isChange = false;
                        var splitted = $scope.exceptionmodel.cob_date
                            .split("-");
                        $scope.cobdate = parseInt(splitted[2]
                            + splitted[0] + splitted[1]);
                        if ($scope.exceptionmodel.is_security) {
                            $scope
                                .getFlagedSecurityExceptionRule($stateParams.id);
                        }
                        $scope.oldModel = angular
                            .copy($scope.exceptionmodel);
                        $scope.historyList = angular.copy(filterdata);
                        $scope.tableParams3.reload();
                        
                    }
                    console.timeEnd("scope.getData: SCREEN");
                });
        		//TODO ADD ERROR CALL
    };
    $scope.getFlagedSecurityExceptionRule = function (id) {
    	console.time("scope.getFlagedSecurityExceptionRule: GET");
        $http.get('/ews/exceptionsummary/getFlagedSecurityExceptionRule/' + id)
            .success(function (data) {
                console.timeEnd("scope.getFlagedSecurityExceptionRule: GET");
                console.time("scope.getFlagedSecurityExceptionRule: SCREEN");

                $scope.FlagedSecurityExceptionRule = data;
                console.timeEnd("scope.getFlagedSecurityExceptionRule: SCREEN");
            });
        	//TODO ADD ERROR CALL
    };
    $scope.getData($stateParams.id);
    // $scope.getFlagedSecurityExceptionRule($stateParams.id);

    $scope.isChange = false;

    $scope.$watch('exceptionmodel', function (entity) {
        $scope.checkDataModification();
    }, true);
    $scope.uploadFile = function (files) {
        $scope.$apply(function ($scope) {
            $scope.files = files;
            $scope.checkDataModification();
        });
    };
    
    angular.isUndefinedOrNull = function(val) {
        return angular.isUndefined(val) || val === null || val == '';
    }

    $scope.checkDataModification = function () {
        if (angular.equals($scope.exceptionmodel, $scope.oldModel) && ($scope.files == undefined)) {
            $scope.isChange = false;
        } else {
            if ($scope.role != 'view_only') {
            	if(!angular.isUndefinedOrNull($scope.exceptionmodel)) {
	            	if (!angular.isUndefinedOrNull($scope.exceptionmodel.status) && angular.equals("3", $scope.exceptionmodel.status) 
	            			&& angular.isUndefinedOrNull($scope.exceptionmodel.comment)) {
	            		$scope.isChange = false;
	            		//toastr.error('Please enter Alert Comment', 'Error');
	            	} else {
	            		$scope.isChange = true;
	            	}	
            	}
            }
        }
    };

    $scope.submitFlaggedExceptionRule = function (flaggedExceptionModel) {
    	console.time("scope.submitFlaggedExceptionRule: GET");
        $scope.setError = "";
        // flaggedExceptionModel.exception_owner =
        // angular.copy(flaggedExceptionModel.exception_owner.value);
        var request = {
            method: 'POST',
            url: '/ews/exceptionsummary/update',
            headers: {
                'Content-Type': undefined
            },

            transformRequest: function (data) {
                var formData = new FormData();

                formData.append('flaggedExceptionModel', new Blob([angular
                    .toJson(flaggedExceptionModel)], {
                    type: "application/json"
                }));
                angular.forEach(data.file, function (file) {
                    formData.append('file', file);
                });
                return formData;
            },
            data: {
                data: flaggedExceptionModel,
                file: $scope.files
            }

        };
        $http(request)
            .success(
                function (data) {
                    console.timeEnd("scope.submitFlaggedExceptionRule: GET");
                    console.time("scope.submitFlaggedExceptionRule: SCREEN");

                    if (data.status) {
                        $scope.isChange = false;

                        $http
                            .get(
                                '/ews/exceptionsummary/get/'
                                + flaggedExceptionModel.exception_id)
                            .success(
                                function (data) {
                                    // $scope.exceptionmodel = {};
                                    $scope.exceptionmodel = data[0];
                                    $scope.oldModel = angular
                                        .copy($scope.exceptionmodel);
                                    $scope.historyList = angular
                                        .copy(data);
                                    $scope.tableParams3.reload();
                                });
                        toastr.success(data.message);
                    } else {
                        toastr.error(data.message, 'Error');
                    }
                    console.timeEnd("scope.submitFlaggedExceptionRule: SCREEN");

                }).error(function () {
            toastr.error('Error while updating alert. Please try again or contact administrator', 'Error');
        });
    };
    $scope.tableParams3 = new NgTableParams({
        page: 1,
        count: 7,
        sorting: {
            exception_activity_id: "desc"
        }

    }, {
        total: $scope.historyList.length,
        getData: function (params) {
            var filteredData3 = params.sorting() ? $filter('orderBy')(
                $scope.historyList, params.orderBy()) : $scope.historyList;

            $scope.data3 = filteredData3.slice((params.page() - 1)
                * params.count(), params.page() * params.count());
            params.total(filteredData3.length);
            return $scope.data3;
        }
    });
};
