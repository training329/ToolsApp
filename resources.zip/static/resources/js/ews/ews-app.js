/**
 * Created by ag52020 on 12/29/2015.
 */

'use strict';

var AngularSpringApp = {};

var App = angular.module('AngularSpringApp', ['ui.router','ngSanitize','ui.select','blockUI','toastr','ngAnimate','ngAutocomplete','ui.bootstrap','dynamicNumber','ngCookies','ngRoute','ngTable','ngCsv','ui.grid','AngularSpringApp.filters', 'AngularSpringApp.services', 'AngularSpringApp.directives', 'isteven-multi-select','ngIdle']);

App.value("CONFIG", {});

App.run(function($http,$rootScope,$location,$cookies, $state,authService, utilService, toastr,CONFIG){
	//$http.defaults.headers.post['X-CSRFToken'] = $cookies.csrftoken;
	authService.user = authService.getUser();
    utilService.getEnviromentDetails();
    	
	    $rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams, error) {

	        if(error.unAuthorized) {
	        	//$cookies.remove('Userinfo');
	        	authService.logout();
	            $state.go('login');
	        }
	        else if(error.authorized){
	           // $state.go('exceptionsummary');
	        }
	    });
	    
	    $rootScope.$on('unauthorized', function() {
	    	authService.logout();
			$state.go('login');
		});
	    
	    $rootScope.$on('serverError', function(event, args){
	    	if(CONFIG && CONFIG.envName && CONFIG.envName != "" && CONFIG.envName.indexOf("prod") == -1 && CONFIG.envName.indexOf("uat") == -1 ) {
	    		toastr.error(args.msg,'Server Error');
	    	}
	    });
	    
	    $rootScope.$on('globalError', function(event, args){
	    	if(CONFIG && CONFIG.envName && CONFIG.envName != "" && CONFIG.envName.indexOf("prod") == -1 && CONFIG.envName.indexOf("uat") == -1 ) {
	    		toastr.warning(args.message,'Warning!! UI ERROR');
	    	} 
	    	utilService.logErrorsToBackend(args.exception);
	    });

	    
});


