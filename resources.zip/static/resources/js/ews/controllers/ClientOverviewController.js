/**
 * added by Avinash
 */
var ClientOverviewController = function($scope,  $state,$stateParams,$location,$cookies, $rootScope,$http,$filter,blockUI, user,toastr,authService) {
	$scope.clientList=[];
	$scope.fundList=[];
	$scope.regionList=[];
	$scope.COBDateList=[];
	$scope.COBDateDaily=[];
	$scope.COBDateMonthly=[];
	$scope.timeperiod="";
	$scope.monthNames = ["Months","Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
	$scope.chartFilter={
			type:"D",
			cob_date:"",
			client:"",
			fund:"",
			region:""
	};
    $scope.type='D';
    $scope.ChangedDate='';
	var result =user;// $cookies.getObject('Userinfo');
	$scope.currentUser=result.name;
	$scope.soeid= result.soeid;
     $scope.role=result.userRole.race_role;


$scope.logout = function() {
		authService.logout().then(function(data){
			$state.go('login');
		})
	}

	$scope.reload=function(){
		$state.reload();
	}
	
	$scope.getChartFilter=function(){
		return{
			type:$scope.type,
			cob_date:$scope.chartFilter.cob_date,
			client:$scope.chartFilter.client,
			fund:$scope.chartFilter.fund,
			region:$scope.chartFilter.region
		}
	}
	$scope.getClientList = function() {
		console.time("scope.getClientList: GET");
		$http.get('/ews/clientoverview/getClientList').success(
						function(data) {
							console.timeEnd("scope.getClientList: GET");
				            console.time("scope.getClientList: SCREEN");
							if(data){
							$scope.clientList =  _.sortBy(data, function(val) {
								return val.text;
							});
							if($stateParams.client!=''){
								$scope.chartFilter.client=$stateParams.client
							}else{
							$scope.chartFilter.client="ALL";
							}
							}
							console.timeEnd("scope.getClientList: SCREEN");
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting clients. Please try again or contact administrator',
											'Error');
						})
	}
	$scope.getFundList=function(client){
		console.time("scope.getFundList: GET");
		$http.get('/ews/clientoverview/getFundList?client='+ encodeURIComponent(client)).success(
				function(data) {
					console.timeEnd("scope.getFundList: GET");
		            console.time("scope.getFundList: SCREEN");
					if(data){
					$scope.fundList = _.sortBy(data, function(val) {
						return val.text;
					});
					if($stateParams.fund!=''){
						$scope.chartFilter.fund=$stateParams.fund;
					}else{
					$scope.chartFilter.fund="ALL";
					}
					}
					console.timeEnd("scope.getFundList: SCREEN");
				},
				function(errResponse) {
					toastr
							.error(
									'Error while getting funds. Please try again or contact administrator',
									'Error');
				})
	}
	$scope.getRegionList=function(fund){
		console.time("scope.getRegionList: GET");
		$http.get('/ews/clientoverview/getRegionList?fund='+encodeURIComponent(fund)).success(
				function(data) {
					console.timeEnd("scope.getRegionList: GET");
		            console.time("scope.getRegionList: SCREEN");
					if(data){
					$scope.regionList = data;
					$scope.chartFilter.region="GLOBAL";
					}
					console.timeEnd("scope.getRegionList: SCREEN");
				},
				function(errResponse) {
					toastr
							.error(
									'Error while getting regions. Please try again or contact administrator',
									'Error');
				})
	}
	
	$scope.getCOBDateList=function(){
		console.time("scope.getCOBDateList: GET");
		$http.get('/ews/clientoverview/getCOBDateList').success(
				function(data) {
					console.timeEnd("scope.getCOBDateList: GET");
		            console.time("scope.getCOBDateList: SCREEN");
					if(data){
						var response=data;
						$scope.COBDateList=	 _.map(response,function(item){
							return{
								"cobvalue":item,
								"date":$filter('dateformat')(item)
							};
						});
					//$scope.COBDateList = data;
					if($stateParams.cobdate!=''){
						$scope.chartFilter.cob_date=$stateParams.cobdate;	
					}else {
					$scope.chartFilter.cob_date=angular.copy(data[0]);
					}
					}	
		            console.timeEnd("scope.getCOBDateList: SCREEN");
				},
				function(errResponse) {
					toastr
							.error(
									'Error while getting Cob Dates. Please try again or contact administrator',
									'Error');
				})
	}
	$scope.getCOBDateListMonthly=function(){
		console.time("scope.getCOBDateListMonthly: GET");
		$http.get('/ews/clientoverview/getMonthlyCOBDateList').success(
				function(data) {
					console.timeEnd("scope.getCOBDateListMonthly: GET");
		            console.time("scope.getCOBDateListMonthly: SCREEN");

					if(data){
						var response=data;
						$scope.COBDateList=	 _.map(response,function(item){
							return{
								"cobvalue":item,
								"date":$scope.monthNames[parseInt(item.toString().substring(4,6))]+ ' - '+item.toString().substring(0, 4)
							};
						});
					$scope.chartFilter.cob_date=angular.copy(data[0]);
					}
					console.timeEnd("scope.getCOBDateListMonthly: SCREEN");
				},
				function(errResponse) {
					toastr
							.error(
									'Error while getting Cob Dates. Please try again or contact administrator',
									'Error');
				})
	}
	//$scope.getCOBDateList();
	//$scope.getCOBDateListMonthly();
	$scope.getClientList();
	
	

	$scope.$watch(
			'chartFilter.client',
			function(client) {
				if(client)
					{
				$scope.getFundList(client);
					}
			});

	$scope.$watch(
			'chartFilter.fund',
			function(fund) {
				if(fund){
				$scope.getRegionList(fund);
				}
			});
	
	$scope.$watch(
			'type',
			function(type) {
				if (type) {
					
					if(type==="D"){
						$scope.timeperiod=" (Daily)";
						$scope.getCOBDateList();
					}else{
						$scope.timeperiod=" (Monthly)";
						$scope.getCOBDateListMonthly();
					}
					
					
					
					if(angular.equals($scope.ChangedDate,$scope.chartFilter.cob_date)|| $scope.ChangedDate==''){
						if ($scope.chartFilter.cob_date && $scope.chartFilter.client && $scope.chartFilter.fund && $scope.chartFilter.region) {
							$scope.getEquityBalanceChart($scope.getChartFilter());
							$scope.getFinincingBalanceChart($scope.getChartFilter());
							$scope.getBalanceSheetROA($scope.getChartFilter());
							$scope.getRevenue($scope.getChartFilter());
							$scope.getSecurityCountryRisk($scope.getChartFilter());
							$scope.getSecurityProduct($scope.getChartFilter());
							$scope.getSecuritySector($scope.getChartFilter());
							$scope.getSecurityMarketCap($scope.getChartFilter());
						}
					}
					$scope.ChangedDate=$scope.chartFilter.cob_date;
				}
			}, true);

	
	$scope.$watch(
			'chartFilter',
			function(client) {
				if (client.cob_date && client.client && client.fund && client.region) {
					$scope.getEquityBalanceChart($scope.getChartFilter());
					$scope.getFinincingBalanceChart($scope.getChartFilter());
					$scope.getBalanceSheetROA($scope.getChartFilter());
					$scope.getRevenue($scope.getChartFilter());
					$scope.getSecurityCountryRisk($scope.getChartFilter());
					$scope.getSecurityProduct($scope.getChartFilter());
					$scope.getSecuritySector($scope.getChartFilter());
					$scope.getSecurityMarketCap($scope.getChartFilter());
				}
			}, true);

	$scope.toggle=function(chart,control){
		
		switch(control)
		{
		case 1:
			$('#chart'+chart+'1').addClass('active');
			$('#chart'+chart+'2').removeClass('active');

			break;
		case 2:
			$('#chart'+chart+'2').addClass('active');
			$('#chart'+chart+'1').removeClass('active');
			break;
		}
	}
	$scope.getFinincingBalanceChart=function(chartFilter){
		console.time("scope.getFinincingBalanceChart: GET");
		var chartcatagories=[];
		var chartSeries=[];
		var credit=[];
		var debit=[];
		var shorts=[];
		var others=[];
	$http.post('/ews/clientoverview/getFinancingBalanceDetails/',chartFilter).success(
			function(data) {
				console.timeEnd("scope.getFinincingBalanceChart: GET");
	            console.time("scope.getFinincingBalanceChart: SCREEN");

				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var Index_Level="";
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);						
				switch(chartFilter.region){
				case "GLOBAL":
					Index_Level="MSCI Global";
					break;
				case "NAM":
					Index_Level="S&P 500";
					break;
				case "APAC":
					Index_Level="Asia Apex 50";
					break;
				case "EMEA":
					Index_Level="MSCI Euro";
					break;
				}
				chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'others'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});	
				chartSeries.push({name:'Credit',data:_.map(_.pluck(out, 'credit'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
				chartSeries.push({name:'Debit',data:_.map(_.pluck(out, 'debit'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				chartSeries.push({name:'Shorts',data:_.map(_.pluck(out, 'shorts'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});		
				chartSeries.push({name:Index_Level, type: 'spline', yAxis: 1,data:_.map(_.pluck(out, 'index_level'),function(value,key,items){return Math.round(value)}),color : '#FFCC00'});
				$scope.plotMixedChart('chart1','Financing Balance'+$scope.timeperiod,chartcatagories,'($ Billions)','',chartSeries);
				console.timeEnd("scope.getFinincingBalanceChart: SCREEN");
			});
	
	}
	$scope.getEquityBalanceChart=function(chartFilter){
		console.time("scope.getEquityBalanceChart: GET");
	var chartcatagories=[];
	var chartSeries=[];
	var Index_Level="";
	$http.post('/ews/clientoverview/getEquityBalanceDetails/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getEquityBalanceChart: GET");
	            console.time("scope.getEquityBalanceChart: SCREEN");

				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);						
				switch(chartFilter.region){
				case "GLOBAL":
					Index_Level="MSCI Global";
					break;
				case "NAM":
					Index_Level="S&P 500";
					break;
				case "APAC":
					Index_Level="Asia Apex 50";
					break;
				case "EMEA":
					Index_Level="MSCI Euro";
					break;
				}
				
				chartSeries.push({name:'Cash',data:_.map(_.pluck(out, 'cash'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});	
				
				chartSeries.push({name:'SMV',data:_.map(_.pluck(out, 'smv'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
				chartSeries.push({name:'LMV',data:_.map(_.pluck(out, 'lmv'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				chartSeries.push({name:'Net Equity', type: 'spline', yAxis: 0,data:_.map(_.pluck(out, 'netequity'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#00bfff'});
				chartSeries.push({name:Index_Level, type: 'spline', yAxis: 1,data:_.map(_.pluck(out, 'index_level'),function(value,key,items){return Math.round(value)}),color : '#FFCC00'});
				
				//chartSeries.push({name:'Total Equity',data:_.map(_.pluck(out, 'totalequity'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#A0728F'});	
				
			
				$scope.plotMixedChart('chart2','Equity Balance'+$scope.timeperiod,chartcatagories,'($ Billions)','',chartSeries);
				console.timeEnd("scope.getEquityBalanceChart: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	}
	
	$scope.getBalanceSheetROA=function(chartFilter){
		console.time("scope.getBalanceSheetROA: GET");
		var chartcatagories=[];
		var chartSeries=[];
		var credit=[];
		var debit=[];
		var shorts=[];
		var others=[];
	$http.post('/ews/clientoverview/getBalanceSheetROA/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getBalanceSheetROA: GET");
	            console.time("scope.getBalanceSheetROA: SCREEN");
				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);							
				//chartSeries.push({name:'Balance Sheet',data:_.map(_.pluck(out, 'balance_sheet'),function(value,key,items){return Math.round(value/100000)/10}),color : '#AEB2EF'});	
				chartSeries.push({name:'Balance Sheet',data:_.map(_.pluck(out, 'without_seclending_balsheet'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				//chartSeries.push({name:'PNL',data:_.map(_.pluck(out, 'pnl'),function(value,key,items){return Math.round(value/100000)/10}),color : '#90CCEF'});
				chartSeries.push({name:'ROA',type: 'spline',  yAxis: 1,data:_.map(_.pluck(out, 'roa'),function(value,key,items){return value}),color : '#00bfff'});		
		
				$scope.plotMixedChart('chart3','Balance Sheet and ROA'+$scope.timeperiod,chartcatagories,'($ Millions)','Gross ROA (bps)',chartSeries);
				console.timeEnd("scope.getBalanceSheetROA: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	}
	$scope.getRevenue=function(chartFilter){
		console.time("scope.getRevenue: GET");
		var chartcatagories=[];
		var chartSeries=[];
		var credit=[];
		var debit=[];
		var shorts=[];
		var others=[];
	$http.post('/ews/clientoverview/getRevenue/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getRevenue: GET");
	            console.time("scope.getRevenue: SCREEN");

				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);					
				//chartSeries.push({name:'PNL',data:_.map(_.pluck(out, 'pnl'),function(value,key,items){return Math.round(value/100000)/10}),color : '#AEB2EF'});	
				
				chartSeries.push({name:'FEE',data:_.map(_.pluck(out, 'fee'),function(value,key,items){return Math.round(value/100)/10}),color : '#4E728F'});
				chartSeries.push({name:'CASH',data:_.map(_.pluck(out, 'cash'),function(value,key,items){return Math.round(value/100)/10}),color : '#969696'});
				chartSeries.push({name:'SHORTS',data:_.map(_.pluck(out, 'shorts'),function(value,key,items){return Math.round(value/100)/10}),color : '#90CCEF'});
						
		
				$scope.plotChart('chart4','PB Revenue'+$scope.timeperiod,chartcatagories,'($ 000s)',chartSeries);
				console.timeEnd("scope.getRevenue: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	}
	$scope.getSecurityCountryRisk=function(chartFilter){
		console.time("scope.getSecurityCountryRisk: GET");
		var chartcatagories=[];
		var chartSeries=[];
		var credit=[];
		var debit=[];
		var shorts=[];
		var others=[];
	$http.post('/ews/clientoverview/getSecurityCountryRisk/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getSecurityCountryRisk: GET");
	            console.time("scope.getSecurityCountryRisk: SCREEN");
				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);				
				chartSeries.push({name:'APAC EM L1',data:_.map(_.pluck(out, 'apac_Emerging_Markets_Lev1'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#AEB2EF'});	
				chartSeries.push({name:'APAC EM L2',data:_.map(_.pluck(out, 'apac_Emerging_Markets_Lev2'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
				chartSeries.push({name:'APAC EM L3',data:_.map(_.pluck(out, 'apac_Emerging_Markets_Lev3'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
				chartSeries.push({name:'Developed',data:_.map(_.pluck(out, 'developed_Markets'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				chartSeries.push({name:'EMEA EM L1B',data:_.map(_.pluck(out, 'emea_Emerging_Markets_Lev1B'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
				chartSeries.push({name:'EMEA EM L2',data:_.map(_.pluck(out, 'emea_Emerging_Markets_Lev2'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});
				chartSeries.push({name:'LATAM EM L2',data:_.map(_.pluck(out, 'latam_Emerging_Markets_Lev2'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});
				chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ffdab9'});
		
				$scope.plotChart('chart5','GMV By Country of Risk'+$scope.timeperiod,chartcatagories,'($ Billions)',chartSeries);
				console.timeEnd("scope.getSecurityCountryRisk: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	}
	$scope.getSecurityProduct=function(chartFilter){
		console.time("scope.getSecurityProduct: GET");
		var chartcatagories=[];
		var chartSeries=[];
		
	$http.post('/ews/clientoverview/getSecurityProduct/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getSecurityProduct: GET");
	            console.time("scope.getSecurityProduct: SCREEN");
				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);		
				chartSeries.push({name:'Preferreds',data:_.map(_.pluck(out, 'preferreds'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
				
				chartSeries.push({name:'Warrants',data:_.map(_.pluck(out, 'warrants'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});
				chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});
				chartSeries.push({name:'Sovereigns',data:_.map(_.pluck(out, 'sovereigns'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
				chartSeries.push({name:'Convertibles',data:_.map(_.pluck(out, 'convertibles'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#AEB2EF'});	
				chartSeries.push({name:'Corporates',data:_.map(_.pluck(out, 'corporates'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
				chartSeries.push({name:'Equities',data:_.map(_.pluck(out, 'equities'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				
				
				$scope.plotChart('chart6','GMV By Product'+$scope.timeperiod,chartcatagories,'($ Billions)',chartSeries);
				console.timeEnd("scope.getSecurityProduct: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	}
	$scope.getSecuritySector=function(chartFilter){
		console.time("scope.getSecuritySector: GET");
		var chartcatagories=[];
		var chartSeries=[];
		
	$http.post('/ews/clientoverview/getSecuritySector/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getSecuritySector: GET");
	            console.time("scope.getSecuritySector: SCREEN");
				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);				
				chartSeries.push({name:'Telecom',data:_.map(_.pluck(out, 'telecommunications'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ffdab9'});
				chartSeries.push({name:'Utils',data:_.map(_.pluck(out, 'utilities'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#a52a2a'});
				chartSeries.push({name:'Consumer staples',data:_.map(_.pluck(out, 'consumer_staples'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
				chartSeries.push({name:'Materials',data:_.map(_.pluck(out, 'materials'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});				
				chartSeries.push({name:'Energy',data:_.map(_.pluck(out, 'energy'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				chartSeries.push({name:'Industrials',data:_.map(_.pluck(out, 'industrials'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
				chartSeries.push({name:'Health care',data:_.map(_.pluck(out, 'health_care'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
				chartSeries.push({name:'Financials',data:_.map(_.pluck(out, 'financials'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#EAB2EF'});
				chartSeries.push({name:'IT',data:_.map(_.pluck(out, 'information_technology'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});
				chartSeries.push({name:'Consumer discretionary',data:_.map(_.pluck(out, 'consumer_discretionary'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#AEB2EF'});
				chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ff8c00'});
		
				$scope.plotChart('chart7','GMV By Sector'+$scope.timeperiod,chartcatagories,'($ Billions)',chartSeries);
				console.timeEnd("scope.getSecuritySector: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	
	}
	
	$scope.getSecurityMarketCap=function(chartFilter){
		console.time("scope.getSecurityMarketCap: GET");
		var chartcatagories=[];
		var chartSeries=[];
		
	$http.post('/ews/clientoverview/getSecurityMarketCap/',chartFilter, {globalErrorsInterceptor:true}).success(
			function(data) {
				console.timeEnd("scope.getSecurityMarketCap: GET");
	            console.time("scope.getSecurityMarketCap: SCREEN");

				//var out=_.sortBy(data,'cob_date').reverse().slice(0,5).reverse();
				var out=data.reverse();
				chartcatagories= $scope.getChartCategories(out);
					
				chartSeries.push({name:'Micro',data:_.map(_.pluck(out, 'micro'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ff8c00'});
				chartSeries.push({name:'Nano',data:_.map(_.pluck(out, 'nano'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
				chartSeries.push({name:'Small',data:_.map(_.pluck(out, 'small'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});				
				chartSeries.push({name:'Big Large',data:_.map(_.pluck(out, 'bigLarge'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});	
				chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
				chartSeries.push({name:'Mid',data:_.map(_.pluck(out, 'mid'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
				chartSeries.push({name:'Mega',data:_.map(_.pluck(out, 'mega'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				$scope.plotChart('chart8','GMV By Market Cap'+$scope.timeperiod,chartcatagories,'($ Billions)',chartSeries);
				console.timeEnd("scope.getSecurityMarketCap: SCREEN");
			});
			//TODO ADD ERROR CALL
	
	}
	$scope.getChartCategories=function(out){
		var cats= _.map(_.pluck(out, 'cob_date'),function(date){
			 var dateString  = date;
		     var year        = dateString.substring(2,4);
		     var month       = dateString.substring(4,6);
		     var day         = dateString.substring(6,8);	
		     var dateobject        = new Date(year, month, day);
			if($scope.type=="D")
				{
			     
				return day+' '+$scope.monthNames[parseInt(month)];
				}else{
					
					return $scope.monthNames[parseInt(month)] + ' '+ year;
				}
			});
		
		return cats;
	}
	$scope.plotChart=function(Chart,ChartTitleText,ChartCatagories,ChartYAxisText,Chartseries){		
		
		console.log("plotting Graph: "+Chart);
		$('#'+Chart)
		.highcharts(
				{  exporting: {
		            chartOptions: { // specific options for the exported image
		                plotOptions: {
		                    series: {
		                        dataLabels: {
		                            enabled: true
		                        }
		                    }
		                }
		            },
		            scale: 3,
		            fallbackToExportServer: false
		        },
					chart : {
						type : 'column',
						zoomType: 'xy',
						backgroundColor:'#F3F3F3'
					},
					title : {
						text : ChartTitleText,
					//align: 'left'
					},

					subtitle : {
						text : '',
						x : -20
					},
					credits : {
						enabled : false
					},
					xAxis : {
						categories : ChartCatagories,
						labels : {
//							rotation : -10
						}

					},
					yAxis : {
						title : {
							text : ChartYAxisText
						},stackLabels: {
			                enabled: true,
			                style: {
			                    fontWeight: 'bold',
			                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
			                },
									    formatter : function() {
										var sum = 0;
										var series = this.axis.series;

										for ( var i in series) {
											if (series[i].visible
													&& series[i].options.stacking == 'normal')
												sum += series[i].yData[this.x];
										}
										if (this.total > 0) {
											return Highcharts.numberFormat(sum,
													1);
										} else {
											return '';
										}
									}
			            },
						// min : 0,
						 // tickInterval: yaxis1Scale,
						enabled : true,
						style : {
							fontWeight : 'bold',
							color : (Highcharts.theme && Highcharts.theme.textColor)
									|| 'gray'
						}

					},
					tooltip : {
						headerFormat : '<span style="font-size:9px;"><b>{point.key}</b></span><table>',
						pointFormat : '<tr><td style="color:{series.color};padding:0;font-size:9px;">{series.name}: </td>'
								+ '<td style="padding:0;font-size:9px;"><b>{point.y}</b></td></tr>',
						footerFormat : '</table>',
						shared : true,
						useHTML : true
					},
					legend : {
						align : 'center',
						//x : -30,
						verticalAlign : 'bottom',
						//y : 10,
						floating : false,
						shadow : false,
						itemStyle:{
							fontSize:'10px'
						}
					},
					plotOptions : {
						column : {
							stacking : 'normal',
							dataLabels : {
								enabled : true,
								color : (Highcharts.theme && Highcharts.theme.dataLabelsColor)
										|| 'white',
								style : {
									textShadow : '0 0 3px gray',
								     fontSize:'9px'
								},
								formatter : function() {
									if (this.y != 0)
										return this.y;
								}

							}
						}
					},
					series :Chartseries
				});
	}
	$scope.plotMixedChart=function(Chart,ChartTitleText,ChartCatagories,ChartYAxisText,ChartYAxisText1,Chartseries){		
		
		console.log("plotting Graph: "+Chart);
		$('#'+Chart)
		.highcharts(
				{
					chart : {
						type : 'column',
						zoomType: 'xy',
						backgroundColor:'#F3F3F3'
					},
					title : {
						text : ChartTitleText,
					//align: 'left'
					},

					subtitle : {
						text : '',
						x : -20
					},
					credits : {
						enabled : false
					},
					xAxis : {
						categories : ChartCatagories,
						labels : {
							//rotation : -15
						}

					},
					yAxis :[ {
						title : {
							text : ChartYAxisText
						},
						//min : 0,
						stackLabels: {
			                enabled: true,
			                style: {
			                    fontWeight: 'bold',
			                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
			                }, 
			                formatter : function() {
								var sum = 0;
								var series = this.axis.series;

								for ( var i in series) {
									if (series[i].visible
											&& series[i].options.stacking == 'normal')
										sum += series[i].yData[this.x];
								}
								if (this.total > 0) {
									return Highcharts.numberFormat(sum,
											1);
								} else {
									return '';
								}
							}
			            },
						// tickInterval: yaxis1Scale,
						enabled : true,
						style : {
							fontWeight : 'bold',
							color : (Highcharts.theme && Highcharts.theme.textColor)
									|| 'gray'
						}
						 

					}, {
						title : {
							text : ChartYAxisText1
						},
						min : 0,
						// tickInterval: yaxis2Scale,
						enabled : true,
						style : {
							fontWeight : 'bold',
							color : (Highcharts.theme && Highcharts.theme.textColor)
									|| 'gray'
						},
						opposite: true

					}],
					tooltip : {
						headerFormat : '<span style="font-size:9px;"><b>{point.key}</b></span><table>',
						pointFormat : '<tr><td style="color:{series.color};padding:0;font-size:9px;">{series.name}: </td>'
								+ '<td style="padding:0;font-size:9px;"><b>{point.y}</b></td></tr>',
						footerFormat : '</table>',
						shared : true,
						useHTML : true
					},
					legend : {
						align : 'center',
						//x : -30,
						verticalAlign : 'bottom',
						//y : 10,
						floating : false,
						shadow : false,
						itemStyle:{
							fontSize:'10px'
						}
					},
					plotOptions : {
						column : {
							stacking : 'normal',
							dataLabels : {
								enabled : true,
								color : (Highcharts.theme && Highcharts.theme.dataLabelsColor)
										|| 'white',
								style : {
									textShadow : '0 0 3px gray',
									fontSize:'9px'
								},
								formatter : function() {
									if (this.y != 0)
										return this.y;
								}

							}
						}
					},
					series :Chartseries
				});
	}
};