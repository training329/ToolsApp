'use strict';

/**
 * ClientProfileController
 * @constructor
 */
var ClientProfileController = function($scope, $location, $rootScope,$http,$filter,$cookies,NgTableParams) {
	
	$("body").removeClass("pageBackGround");
	$scope.currentUser = $cookies.currentUser;
	$scope.logout = function() {
		console.time("scope.logout: GET");
		$http.get('/ews/sso/logout').success(function(data) {
			console.timeEnd("scope.logout: GET");
            console.time("scope.logout: SCREEN");
			$cookies.currentUser = null;
			$state.go('login');
			console.timeEnd("scope.logout: SCREEN");
		});
		//TODO ADD ERROR CALL
	}
   
};