/**
 * Created by ag52020 on 12/30/2015.
 */
'use strict';

/* Services */

var AppServices = angular.module('AngularSpringApp.services', []);

//AppServices.value('version', '0.1');

AppServices.factory('exceptionservice',['$http','$q',function($http,$q){
	
	return{
		logout:function(){
			return $http.get('/ews/sso/logout')
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while LOGOUT');
						return $q.reject(errResponse);
					}
			);
		},
		getAlertRules:function(){
			return $http.get('/ews/exceptionrule/exceptionrulelist.json')
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching alert rules');
						return $q.reject(errResponse);
					}
			);
		},
		getClients:function(){
			return $http.get('/ews/exceptionrule/clientslist.json')
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching clients');
						return $q.reject(errResponse);
					}
			);
		},
		getFunds:function(client){
			return $http.get('/ews/exceptionrule/getfunds/'+ client)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching funds');
						return $q.reject(errResponse);
					}
			);
		},
		getLegalEntities:function(client,fund){
			return $http.get('/ews/exceptionrule/getlegalentities/'+client + '/' + fund)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching legal entities');
						return $q.reject(errResponse);
					}
			);
		},
		getRegions:function(client,fund,entity){
			return $http.get('/ews/exceptionrule/getregions/'+ client + '/'+ fund + '/' + entity)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching regions');
						return $q.reject(errResponse);
					}
			);
		},
		getMeasures:function(){
			return $http.get('/ews/exceptionrule/getmeasures/')
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching measures');
						return $q.reject(errResponse);
					}
			);
		},
		getMasters:function(){
			return $http.get('/ews/exceptionrule/getmasters/')
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching masters');
						return $q.reject(errResponse);
					}
			);
		},
		addExceptionRule:function(exceptionmodel){
			return $http.post('/ews/exceptionrule/add', exceptionmodel)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while Adding Exception rule');
						return $q.reject(errResponse);
					}
			);
		},
		getExceptionRule:function(id){
			return $http.get('/ews/exceptionrule/get/' +id)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching Exception rule');
						return $q.reject(errResponse);
					}
			);
		},
		getAlerts:function(id){
			return $http.get('/ews/exceptionrule/getAlerts/' +id)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching alerts');
						return $q.reject(errResponse);
					}
			);
		},
		updateExceptionRule:function(exceptionmodel){
			return $http.put('/ews/exceptionrule/update', exceptionmodel)
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching Exception rule');
						return $q.reject(errResponse);
					}
			);
		}
	};
	
}]);

AppServices.factory('authService',['$http', '$state', 'Idle',function($http, $state, Idle){
	
//	return{
//		getUser:function(){
//			return $http.get('/ews/sso/getuser')
//			.then(
//					function(response){
//						return response.data;
//					}, 
//					function(errResponse){
//						console.error('Error while fetching Exception rule');
//						return $q.reject(errResponse);
//					}
//			);
//		}
//	};
	
    var auth={};

    auth.login=function(dataObj){
        return $http.post("/ews/sso/authenticate",dataObj).then(function(response,status){
            auth.user=response.data;
            //$cookies.putObject('Userinfo',auth.user);
            return auth.user;
        });
    }

    auth.logout=function(){
        return $http.get('/ews/sso/logout').then(function(response){
            auth.user=undefined;
            $('#' + "loginpage").show();
            $state.go('login');
           // $cookies.remove('Userinfo');
        });
    }
    auth.getUser=function(){
    	return $http.get('/ews/sso/getuser/').then(function(response){
    		// after browser referesh if user session exists then start watching again.
    	   if(response.data && response.data.isAuthenticated == true){
    		   Idle.watch();
    		   auth.user=response.data;
    		   $('#' + "loginpage").hide();
    	   }
           return response.data;
        });
    }
    return auth;

	
	
}]);

angular.module('AngularSpringApp').service('APIInterceptor', function($rootScope, $q, HTTP_STATUS) {
	var service = this;
   	service.responseError = function(response) {
	    if (response.status === HTTP_STATUS.UNAUTHORIZED || response.status === HTTP_STATUS.FORBIDDEN) {
	    	 $rootScope.$broadcast('unauthorized');
	    }else if (response.status === HTTP_STATUS.INTERNAL_SERVER_ERROR) {
	    	if(response.config.globalErrorsInterceptor){
	    		$rootScope.$broadcast('serverError', {msg : response.data.message});
	    	}
	    	return $q.reject(response);
	    	
	    }
	    return $q.reject(response);
	};
});

AppServices.factory('adminService',['$http','$q',function($http,$q){
	
	return{
		getEWSUsers:function(){
			return $http.get('/ews/admin/getEWSUsers/')
			.then(
					function(response){
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching users');
						return $q.reject(errResponse);
					}
			);
		}
	};
	
}]);


AppServices.factory('utilService',['$http','$q', '$injector', 'CONFIG', 'authService', 'toastr' , function($http,$q, $injector, CONFIG, authService, toastr){
	
	return{
		getEnviromentDetails:function(){
			return $http.get('/ews/getEnviromentDetails/')
			.then(
					function(response){
						CONFIG.envName = response.data.envName;
						CONFIG.buildVersion = response.data.buildVersion;
						return response.data;
					}, 
					function(errResponse){
						console.error('Error while fetching getEnviromentDetails');
						return $q.reject(errResponse);
					}
			);
		},
		
		saveFile:function(blob, fileName) {
		    if (window.navigator.msSaveOrOpenBlob) { // for IE
		        navigator.msSaveOrOpenBlob(blob, fileName);
		    } else {
		        var link = document.createElement('a');
		        link.href = window.URL.createObjectURL(blob);
		        link.download = fileName;
		        link.click();
		        window.URL.revokeObjectURL(link.href);
		    }
		},
		
		confirmDialog :  function(message, title, buttonLabels){
			var defer = $q.defer();
			var callback = function (event) {
				 if(event.target.id == 'okButton'){
					 defer.resolve(); 
				 }else{
					 defer.reject();
				 }
        	};
        	toastr.clear();
        	toastr.info(  '<br /><div><p>' + message + '</p></div>'+
		           '<button type="button" class="btn clear">'+buttonLabels[0]+'</button>    ' +
		           '<button id="okButton"  class="btn btn-warning">'+buttonLabels[1]+'</button>', 
		           title, {
        			closeButton: true,
        			preventDuplicates: true,
        	        onShown: () {
                        event.onclick = callback;
                    },
                    timeOut: 10000, 
                    extendedTimeOut: 10000,
                    progressBar: true,
        			allowHtml: true
        		});
			    return defer.promise
		},
		
		logErrorsToBackend :  function(exception){
			var $window = $injector.get('$window');
	        var $location = $injector.get('$location');
	        var $http = $injector.get('$http');
	        var lastLog = new Date();
	        var sentData = {};
	          sentData.message= exception.message;
	          sentData.url = $location.absUrl();
	          sentData.timestamp = lastLog.toISOString();
	          sentData.userAgent = $window.navigator.userAgent;
	          
	          if(authService.user && authService.user.name){
	        	  sentData.username = authService.user.name; 
	          }
	          sentData.level = 'ERROR';
			  sentData.stack= exception.stack
			  
			  var errorMessage = "";
			  for (var label in sentData) {
				  errorMessage += label +" : " + sentData[label] +"\n";
		      }
	    	
	    	$http.put('/ews/logClientErrors/', errorMessage)
			.then(
					function(response){
						console.log('logged successfullly');
						return response;
					}, 
					function(errResponse){
						console.error('Error while loging error to backend');
						return $q.reject(errResponse);
					}
			);
	    }
	
	
	
	};	


}]);

