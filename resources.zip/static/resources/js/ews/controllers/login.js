var LoginController = function($scope,$cookies,$state, $location, $rootScope,$http,toastr,authService,Idle) {
//	 $('body').addClass('pageBackGround');
    $scope.submit = function(){
        var uname = 'GP58292';  //$rootscope
        var password = 'GopalUat7';

        var dataObj = {
            soeid : uname,
            password : password
        };
        

		        authService.login(dataObj).then(function(data) {
			if (data.status_Code == 'EWS_1000') {
				toggleLoginChangePwd();
			} else {
				if (data.isAuthenticated) {
					if (data.isAuthorized) {
						Idle.watch();	
						$state.go('exceptions');
						$('#' + "loginpage").hide();
					} else {
						toastr.error('User not Authorised', 'Error');
					}
				} else if (data.statusCode == "EWS_1000") {
					$('#' + "toggleLoginPwd").html("<strong>Log In</strong>");
					clearData();
					$('#' + "loginbox").hide();
					$('#' + "changebox").show();
					toastr.error('Please change your password', 'Alert');
				} else {
					toastr.error('User not Authenticated', 'Error');
				}

			}

		})

// var res = $http.post('/ews/sso/authenticate', dataObj);
// res.success(function(data, status, headers, config) {
// $scope.message = data;
//
//            if (data.isAuthenticated) {
//            	if(data.isAuthorized){
//            	
//            	$cookies.currentUser= data.name;
//            	$cookies.soeid= data.soeid;
//                $rootScope.loggedIn = true;
//                $location.path('/exceptionsummary');
//            	}else{
//            		toastr.error('User not Authorised', 'Error');
//            	}
//            } else if (data.statusCode == "EWS_1000"){
//            	 $('#' + "toggleLoginPwd").html("<strong>Log In</strong>");
//            	 clearData();
//            	 $('#' + "loginbox").hide();
//                 $('#' + "changebox").show();
//                 toastr.error('Please change your password', 'Alert');
//            }else {
//            	toastr.error('User not Authenticated', 'Error');
//            }
//            
//           
//        });
//        res.error(function(data, status, headers, config) {
//            
//        	 toastr.error('Error encountered', 'Error');
//        });
    };




       /* if($scope.username == 'admin' && $scope.password == 'admin'){
            $rootScope.loggedIn = true;
            $location.path('/clientprofile');
        } else {
            alert('Incorrect Information');
        }*/
    $scope.changePwd = function(){
    	console.time("scope.changePwd: GET");
        var uname = $scope.change_soeid;  //$rootscope
        var oldpassword = $scope.change_oldpassword;
        var newpassword = $scope.change_newpassword;
        var confirmpassword = $scope.change_newpasswordconfirm;
        
        if (uname === null || oldpassword === null || newpassword === null || confirmpassword === null || (confirmpassword !== newpassword)) {
        //alert("<img src='/ews-web/resources/img/warning.gif'> Please enter correct soeid and password and click Change Password", false);
        	alert("Please enter valid values");
        return false;
    }
        
        
        var dataObj = {
            soeid : uname,
            password : oldpassword,
            newpassword : newpassword
        };


        //console.log(JSON.stringify(dataObj));

        //console.log("data obj="+dataObj);
        var res = $http.post('/ews/sso/changePassword', dataObj);
        res.success(function(data, status, headers, config) {
			console.timeEnd("scope.changePwd: GET");
            console.time("scope.changePwd: SCREEN");

            $scope.message = data;

            if (data.isAuthenticated) {
            	//$rootScope.currentUser=data;
            	//$cookies.currentUser= data.soeid;
                //$rootScope.loggedIn = true;
            	 
                 $('#' + "changebox").hide();
                 $('#' + "loginbox").show();
                 toastr.success('Change password Successful', 'Alert');
                //alert("Password reset is successful")
                
                //$location.path('/exceptionsummary');
            }else{
            	toastr.error('User not Authenticated', 'Error');
            }
            console.timeEnd("scope.changePwd: SCREEN");
        });
        res.error(function(data, status, headers, config) {
            alert( "failure message: " + JSON.stringify({data: data}));
        });
        // Making the fields empty
        //

    }
};

var toggleLoginPwd = 1;
$.ajaxSetup({cache: false});

function goforward() {
    window.history.forward(1);
}

window.onbeforeunload = goforward();
function toggleLoginChangePwd($scope, $location){
	//window.location.href ="/ews/html/partials/login/layout.html";
	if (toggleLoginPwd == 2) {
        toggleLoginPwd = 1;
        $('#' + "toggleLoginPwd").html("<strong>Change Password</strong>");
        clearData();
        $('#' + "loginbox").show();
        $('#' + "changebox").hide();
        
	}else{
	 toggleLoginPwd = 2;
	 $('#' + "toggleLoginPwd").html("<strong>Log In</strong>");	 
	 clearData();
	 $('#' + "loginbox").hide();
     $('#' + "changebox").show();
	}
};

function clearData($scope){

    $('#' + "username").val('');
    $('#' + "login-password").val('');
	$('#' + "change_soeid").val('');
	$('#' + "change_oldpassword").val('');
	$('#' + "change_newpassword").val('');
	$('#' + "change_newpasswordconfirm").val('');
	 
}
