'use strict';
/*

angular.module('app.constants').constant('propertiesConstant', {
    API_URL: '/api'
});*/

angular.module('AngularSpringApp').constant('HTTP_STATUS', {
	'UNAUTHORIZED': 401,
	'FORBIDDEN': 403,
	'INTERNAL_SERVER_ERROR': 500
});

