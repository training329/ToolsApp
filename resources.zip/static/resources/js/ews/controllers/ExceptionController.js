/**
 * added by aw11769
 */

var ExceptionController = function($scope, $cookies, $state, $location,
		$stateParams, $rootScope, $http, $filter, $q, $state, NgTableParams,user,
		toastr, exceptionservice, authService) {
	$scope.exceptionmodel = {};
	$scope.Exceptions = [];
	$scope.legalEntityList = [];
	$scope.clientList = [];
	$scope.fundList = [];
	$scope.historyList = [];
	$scope.regionsList = [];

	$scope.agg = [];
	$scope.oldThresholdDollar = 0;
	$scope.oldThresholdpercent = 0;
	var result = user;//$cookies.getObject('Userinfo');
	$scope.currentUser = result.name;
	$scope.soeid = result.soeid;
	$scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;
    
	$scope.logout = function() {
		authService.logout().then(function(data) {
			$state.go('login');
		})
	}
	// $("body").removeClass("pageBackGround");
	$scope.checkType = function(currencyType) {
		if (currencyType == '$')
			return true;

		return false;
	}
	$scope.checkTypePercent = function(currencyType) {

		if (currencyType == '%')
			return true;

		return false;

	}
	$scope.fetchExceptionList = function() {
		exceptionservice
				.getAlertRules()
				.then(
						function(data) {
							$scope.Exceptions = _.sortBy(data, function(val) {
								return -val.rule_id
							});
							$scope.tableParams.reload();
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting alert rules. Please try again or contact administrator',
											'Error');
						})
	}
	$scope.fetchExceptionList();

	$scope.tableParams = new NgTableParams({
		page : 1,
		count : 18,
		sorting : {
			total_open_alerts:"desc",
			rule_group_id:"desc"
		}
	}, {
		total : $scope.Exceptions.length,
		getData : function(params) {

			$scope.data = params.sorting() ? $filter('orderBy')(
					$scope.Exceptions, params.orderBy()) : $scope.Exceptions;
			var filteredData = searchData($scope.data);
			$scope.data = filteredData.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData.length);
			return $scope.data;
		}
	});
	$scope.Searchterm = '';

	$scope.applyGlobalSearch = function(term) {
		$scope.tableParams.filter({
			$ : term
		});

	}

	var searchData = function(data) {
		if ($scope.Searchterm)
			return $filter('filter')(data, $scope.Searchterm);
		return data;
	}

};

var ExceptionAddController = function($scope, $cookies, $state, $location,
		$stateParams, $rootScope, $http, $filter, $q, $state, NgTableParams,user,
		toastr, exceptionservice, authService) {

	$scope.exceptionmodel = {};
	$scope.Exceptions = [];
	$scope.legalEntityList = [];
	$scope.clientList = [];
	$scope.fundList = [];
	$scope.clientListIncludingAll=[];
	$scope.oldclientList=[];
	$scope.historyList = [];
	$scope.regionsList = [];
	$scope.agg = [];

	$scope.isChange = true;
	$scope.threshold1 = false;
	$scope.threshold2 = false;
	$scope.Reset = function() {

		$scope.exceptionmodel = {};
		$scope.isChange = true;
		$scope.threshold1 = false;
		$scope.threshold2 = false;
	}
	var result = user;//$cookies.getObject('Userinfo');
	$scope.currentUser = result.name;
	$scope.soeid = result.soeid;
	$scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;

	$scope.logout = function() {
		authService.logout().then(function(data) {
			$state.go('login');
		})
	}
	$scope.change=function(val){
		if (val === 'threshold1') {
			if (!$scope.threshold1) {
				
				$scope.exceptionmodel.threshold_dollar = 0;
			}
		}
			

		if (val === 'threshold2') {
			if (!$scope.threshold2) {
				
				$scope.exceptionmodel.threshold_percent = 0;
			}
		}
		
	}
	$scope.getAllUsers = function(exceptionRuleType,client) {
		console.time("scope.getAllUsers: GET");
		$http.get('/ews/exceptionrule/getUsersOnExceptionType/' + exceptionRuleType+'/'+client, {globalErrorsInterceptor:true})
				.success(function(response) {
                    console.timeEnd("scope.getAllUsers: GET");
                    console.time("scope.getAllUsers: SCREEN");
					$scope.users = response;
					console.timeEnd("scope.getAllUsers: SCREEN");
				});
				//TODO ADD ERROR CALL

	};
	$scope.getClientList = function() {
		exceptionservice
				.getClients()
				.then(
						function(data) {
							$scope.oldclientList = _.sortBy(data, function(val) {
								return val.text
							});
							$scope.clientList = angular.copy($scope.oldclientList);
							$scope.clientListIncludingAll = _.filter(angular.copy($scope.oldclientList), function(item){
								return item.text!='ALL';
							});
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting clients. Please try again or contact administrator',
											'Error');
						})
	}
	$scope.formatLabel = function(model) {
		
		if (model != undefined) {
			var filteredGoal = _.filter($scope.users, function(num) {
				var resut = $filter('lowercase')(num.value) == $filter(
						'lowercase')(model);
				return resut;
			});
			if (filteredGoal.length > 0) {
				return filteredGoal[0].text;
			} else {
				return model;
			}
		} else {
			return ''
		}
	}
	$scope
			.$watch(
					'exceptionmodel.client',
					function(client) {
						if (client) {
							if($scope.exceptionmodel.exceptionRuleType=='1'){
								$scope.exceptionmodel.fund = '';
							}
							exceptionservice
									.getFunds(client)
									.then(
											function(data) {
												var fundList = _.sortBy(data, function(val) {
													return val.text
												});
												$scope.fundList = fundList;
												if($scope.exceptionmodel.exceptionRuleType=='1'){
													$scope.exceptionmodel.fund = '9999999999';
												}
											},
											function(errResponse) {
												toastr
														.error(
																'Error while getting funds. Please try again or contact administrator',
																'Error');
											})
											
											if($scope.exceptionmodel.exceptionRuleType!='')
												{
												$scope.getAllUsers($scope.exceptionmodel.exceptionRuleType,client);
												}
						}
					}, true);

	$scope
			.$watch(
					'exceptionmodel.fund',
					function(fund) {
						if (fund) {
							if($scope.exceptionmodel.exceptionRuleType=='1'){
								$scope.exceptionmodel.legalEntity = "";
							}
							exceptionservice
									.getLegalEntities(
											$scope.exceptionmodel.client, fund)
									.then(
											function(data) {
												$scope.legalEntityList = data;
												if($scope.exceptionmodel.exceptionRuleType=='1'){
													$scope.exceptionmodel.legalEntity = "26";
												}
											},
											function(errResponse) {
												toastr
														.error(
																'Error while getting legal entities. Please try again or contact administrator',
																'Error');
											})
						}

					}, true);
	$scope
			.$watch(
					'exceptionmodel.legalEntity',
					function(entity) {
						if (entity) {
							if($scope.exceptionmodel.exceptionRuleType=='1'){
								$scope.exceptionmodel.region = "";
							}
							exceptionservice
									.getRegions($scope.exceptionmodel.client,
											$scope.exceptionmodel.fund, entity)
									.then(
											function(data) {

												$scope.regionsList = data;
												$scope.regionsList1 = angular
														.copy(data);
												if($scope.exceptionmodel.exceptionRuleType=='1'){
													$scope.exceptionmodel.region = "1";
												}
											},
											function(errResponse) {
												toastr
														.error(
																'Error while getting regions. Please try again or contact administrator',
																'Error');
											})

						}

					}, true);

	$scope.Thresholdchecked = function(type) {
		if (type == 'Dollar') {
			if ($scope.threshold1) {
				$('#ThresholdDollar').focus();

			}
		} else {
			if ($scope.threshold2)
				$('#ThresholdPercent').focus();
		}
	}

	$scope.$watch('exceptionmodel.exceptionRuleType', function(ruleType) {
		$scope.regionsList = angular.copy($scope.regionsList1);
		$scope.clientList=$scope.oldclientList;
		if(ruleType=='3')
			{
			exceptionservice
			.getRegions('999999','9999999999', '26')
			.then(
					function(data) {

						$scope.regionsList = data;
						$scope.regionsList1 = angular
								.copy(data);
						
					},
					function(errResponse) {
						toastr
								.error(
										'Error while getting regions. Please try again or contact administrator',
										'Error');
					})
			}
		if (!$scope.editrule) {

			if (ruleType == '2' || ruleType == '3') {
				$scope.exceptionmodel.client = '999999';
				$scope.exceptionmodel.fund = '9999999999';
				$scope.exceptionmodel.legalEntity = "26";

				$scope.exceptionmodel.aggregation_level = '1';

				if (ruleType == '2') {
					$scope.exceptionmodel.region = "1";
				}
			} else if (ruleType == '1') {
				$scope.clientList = $scope.clientListIncludingAll ;
				
//				$scope.exceptionmodel.client = '999999';
//				$scope.exceptionmodel.fund = '9999999999';
//				$scope.exceptionmodel.legalEntity = "26";
//				$scope.exceptionmodel.aggregation_level = '1';
//				$scope.exceptionmodel.region = "1";
				$scope.exceptionmodel.client = '';
				$scope.exceptionmodel.fund = '';
				$scope.exceptionmodel.legalEntity = "";
				$scope.exceptionmodel.aggregation_level = '';
				$scope.exceptionmodel.region = "";
			}
		}
		if (ruleType) {
			if ($scope.exceptionmodel.client != '') {
				$scope.getAllUsers(ruleType,
						$scope.exceptionmodel.client);
			}
		}
	});

	$scope.getMeasures = function() {

		exceptionservice
				.getMeasures()
				.then(
						function(data) {
							$scope.measures = data;
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting measures. Please try again or contact administrator',
											'Error');
						})

	}

	$scope.getMasters = function() {
		$scope.priorityTypes = [];
		$scope.limits = [];
		$scope.periods = [];
		$scope.statusTypes = [];
		$scope.ruleTypes = [];
		$scope.thresholdTypes = [];
		$scope.agg = [];
		exceptionservice
				.getMasters()
				.then(
						function(data) {
							angular.forEach(data, function(master, index) {
								switch (master.type) {
								case "priority_type":
									$scope.priorityTypes.push(master);
									break;
								case "rule_limits":
									$scope.limits.push(master);
									break;
								case "rule_period":
									$scope.periods.push(master);
									break;
								case "rule_status_type":
									$scope.statusTypes.push(master);
									break;
								case "rule_type":
									$scope.ruleTypes.push(master);
									break;
								case "threshold_type":
									$scope.thresholdTypes.push(master);
									break;
								case "aggr_level":
									$scope.agg.push(master);
									break;
								}
							});
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting masters. Please try again or contact administrator',
											'Error');
						});

	}
	$scope.getMasters();
	$scope.getClientList();
	$scope.getMeasures();

	$scope.submitExceptionRule = function(exceptionmodel) {

		if ($scope.threshold1 == false && $scope.threshold2 == false) {
			toastr
					.error(
							'Threshold value is not selected. Please select atleast one',
							'Error');
			return false;
		} else if ($scope.threshold1 == true) {
			if (exceptionmodel.threshold_dollar == 0) {
				toastr.error('Threshold value should be greater than zero.',
						'Error');
				return false;
			}
		} else {
			if (exceptionmodel.threshold_percent == 0) {
				toastr.error('Threshold value should be greater than zero.',
						'Error');
				return false;
			}
		}
		exceptionservice
				.addExceptionRule(exceptionmodel)
				.then(
						function(data) {	
							if (data.status) {
								toastr.success('New alert rule added succesfully');	
								$scope.isChange = false;
							} else {
								toastr.error(data.message,
										'Error');
							}
						},
						function(errResponse) {
							toastr
									.error(
											'Error while adding exception rule. Please try again or contact administrator',
											'Error');
						});

	}
};

var ExceptionEditController = function($scope, $cookies, $state, $location,
		$stateParams, $rootScope, $route, $http, $filter, $q, $state,user,
		NgTableParams, toastr, exceptionservice, authService) {
	$scope.exceptionmodel = {};
	$scope.Exceptions = [];
	$scope.legalEntityList = [];
	$scope.clientList = [];
	$scope.fundList = [];
	$scope.historyList = [];
	$scope.regionsList = [];
	$scope.users=[];
	$scope.alerts = [];
	// $scope.currentUser = $cookies.currentUser;

	var result =user;// $cookies.getObject('Userinfo');
	$scope.currentUser = result.name;
	$scope.soeid = result.soeid;
	$scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;

	$scope.showPriority = function(agestring, priority, color) {
		var age = parseInt(agestring);
		switch (color) {
		case "RED":
			if (priority === 'High') {
				return true;
			} else if (priority === 'Medium') {
				return age >= 5;
			} else if (priority === 'Low') {
				return age > 5;
			} else {
				return false;
			}

			break;
		case "GREEN":
			if (priority === 'Medium') {
				return age <= 1;
			} else if (priority === 'Low') {
				return age <= 2;
			} else {
				return false;
			}
			break;
		case "YELLOW":
			if (priority === 'Medium') {
				return (age >= 2 && age <= 4);
			} else if (priority === 'Low') {
				return (age >= 3 && age <= 5);
			} else {
				return false;
			}
			break;
		}

	}
	$scope.logout = function() {
		authService.logout().then(function(data) {
			$state.go('login');
		})
	}
	$scope.tableParams1 = new NgTableParams({
		page : 1,
		count : 5,
		sorting : {
			exception_activity_id : "desc"
		}

	}, {
		total : $scope.historyList.length,
		getData : function(params) {
			var filteredData3 = [];
			filteredData3 = params.sorting() ? $filter('orderBy')(
					$scope.historyList, params.orderBy()) : $scope.historyList;

			$scope.data1 = filteredData3.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData3.length);
			return $scope.data1;
		}
	});
	$scope.getAllUsers = function(exceptionRuleType,client) {
		console.time("scope.getAllUsers: GET");
		$http.get('/ews/exceptionrule/getUsersOnExceptionType/' + exceptionRuleType+'/'+client, {globalErrorsInterceptor:true})
				.success(function(response) {
                    console.timeEnd("scope.getAllUsers: GET");
                    console.time("scope.getAllUsers: SCREEN");
					$scope.users = response;
					console.timeEnd("scope.getAllUsers: SCREEN");
				});
				//TODO ADD ERROR CALL

	};
	
$scope.formatLabel = function(model) {
		
		if (model != undefined) {
			var filteredGoal = _.filter($scope.users, function(num) {
				var resut = $filter('lowercase')(num.value) == $filter(
						'lowercase')(model);
				return resut;
			});
			if (filteredGoal.length > 0) {
				return filteredGoal[0].text;
			} else {
				return ($scope.exceptionmodel != null && $scope.exceptionmodel.alert_owner != null)? $scope.exceptionmodel.alert_owner : model;
			}
		} else {
			return ''
		}
	}
	$scope.change=function(val){
		if (val === 'threshold1') {
			if ($scope.threshold1) {
				$scope.exceptionmodel.threshold_dollar = $scope.exceptionmodel.threshold_dollar_old;
			} else {
				
				$scope.exceptionmodel.threshold_dollar = 0;
			}
		}
			

		if (val === 'threshold2') {
			if ($scope.threshold2) {
				$scope.exceptionmodel.threshold_percent = $scope.exceptionmodel.threshold_percent_old;
			} else {
			
				$scope.exceptionmodel.threshold_percent = 0;
			}
		}
		
	}
	$scope.tableParams2 = new NgTableParams({
		page : 1,
		count : 5,
		sorting : {
			cob_date : "desc"
		}

	}, {
		total : $scope.alerts.length,
		getData : function(params) {

			$scope.data2 = params.sorting() ? $filter('orderBy')(
					$scope.alerts, params.orderBy())
					: $scope.alerts;
			$scope.data2 = $scope.data2.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total($scope.alerts.length);
			return $scope.data2;
		}
	});
	$scope.getClientList = function() {
		exceptionservice
				.getClients()
				.then(
						function(data) {
							$scope.clientList = data;
							
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting clients. Please try again or contact administrator',
											'Error');
						})
	}

	$scope.getAlerts = function(id) {
		exceptionservice
				.getAlerts(id)
				.then(
						function(data) {
							$scope.alerts = data;
							$scope.tableParams2.reload();
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting Alerts. Please try again or contact administrator',
											'Error');
						})
	}

	$scope
			.$watch(
					'exceptionmodel.client',
					function(client) {
						if (client) {
							exceptionservice
									.getFunds(client)
									.then(
											function(data) {
												$scope.fundList = data;
											},
											function(errResponse) {
												toastr
														.error(
																'Error while getting funds. Please try again or contact administrator',
																'Error');
											})
						}
					});
	$scope.Thresholdchecked = function(type) {
		if (type == 'Dollar') {
			if ($scope.threshold1) {
				$('#ThresholdDollar').focus();
			}
		} else {
			if ($scope.threshold2)
				$('#ThresholdPercent').focus();
		}
	}
	$scope
			.$watch(
					'exceptionmodel.fund',
					function(fund) {
						if (fund) {

							exceptionservice
									.getLegalEntities(
											$scope.exceptionmodel.client, fund)
									.then(
											function(data) {
												$scope.legalEntityList = data;
											},
											function(errResponse) {
												toastr
														.error(
																'Error while getting legal entities. Please try again or contact administrator',
																'Error');
											})
						}

					});
	$scope
			.$watch(
					'exceptionmodel.legalEntity',
					function(entity) {
						if (entity) {

							exceptionservice
									.getRegions($scope.exceptionmodel.client,
											$scope.exceptionmodel.fund, entity)
									.then(
											function(data) {
												$scope.regionsList = data;
											},
											function(errResponse) {
												toastr
														.error(
																'Error while getting regions. Please try again or contact administrator',
																'Error');
											})

						}

					});
	$scope.checkType = function(currencyType) {

		if (currencyType == '$')
			return true;

		return false;

	}
	$scope.checkTypePercent = function(currencyType) {

		if (currencyType == '%')
			return true;

		return false;

	}

	$scope.getMeasures = function() {

		exceptionservice
				.getMeasures()
				.then(
						function(data) {
							$scope.measures = data;
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting measures. Please try again or contact administrator',
											'Error');
						})

	}

	$scope.getMasters = function() {
		$scope.priorityTypes = [];
		$scope.limits = [];
		$scope.periods = [];
		$scope.statusTypes = [];
		$scope.ruleTypes = [];
		$scope.thresholdTypes = [];
		$scope.agg = [];
		exceptionservice
				.getMasters()
				.then(
						function(data) {
							angular.forEach(data, function(master, index) {
								switch (master.type) {
								case "priority_type":
									$scope.priorityTypes.push(master);
									break;
								case "rule_limits":
									$scope.limits.push(master);
									break;
								case "rule_period":
									$scope.periods.push(master);
									break;
								case "rule_status_type":
									$scope.statusTypes.push(master);
									break;
								case "rule_type":
									$scope.ruleTypes.push(master);
									break;
								case "threshold_type":
									$scope.thresholdTypes.push(master);
									break;
								case "aggr_level":
									$scope.agg.push(master);
									break;
								}
							});
						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting masters. Please try again or contact administrator',
											'Error');
						});

	}
	$scope.loadData = function(id) {

		var loadDatapromice = exceptionservice.getExceptionRule(id)

		loadDatapromice
				.then(
						function(data) {
							var filterdata = _.sortBy(data, function(val) {
								return -val.rule_id
							});
							$scope.getAllUsers(filterdata[0].exceptionRuleType,filterdata[0].client);
							//console.log(filterdata);
							$scope.exceptionmodel = {};
							$scope.exceptionmodel = angular.copy(filterdata[0]);
							$scope.exceptionmodel.exceptionComments='';
							$scope.getAllUsers($scope.exceptionmodel.exceptionRuleType,$scope.exceptionmodel.client);
							if ($scope.exceptionmodel.threshold_dollar) {
								$scope.exceptionmodel.threshold_dollar_old=angular.copy($scope.exceptionmodel.threshold_dollar);
								$scope.threshold1 = true;
								$scope.threshold1_old=true;
							}
							if ($scope.exceptionmodel.threshold_percent) {
								$scope.exceptionmodel.threshold_percent_old=angular.copy($scope.exceptionmodel.threshold_percent)
								$scope.threshold2 = true;
								$scope.threshold2_old=true;
							}
							$scope.oldModel = angular
									.copy($scope.exceptionmodel);
							$scope.historyList = angular.copy(filterdata);
							$scope.tableParams1.reload();
							
							
						

						},
						function(errResponse) {
							toastr
									.error(
											'Error while getting exception rule. Please try again or contact administrator',
											'Error');
						});
	}
	$scope.getMasters();
	$scope.getClientList();
	$scope.getAlerts($stateParams.id);
	$scope.getMeasures();
	$scope.oldModel = {};
	$scope.loadData($stateParams.id);
	$scope.submitExceptionRule = function(exceptionmodel) {
		if ($scope.threshold1 == false && $scope.threshold2 == false) {
			toastr
					.error(
							'Threshold value is not selected. Please select atleast one',
							'Error');
			return false;
		} else if ($scope.threshold1 == true) {
			if (exceptionmodel.threshold_dollar == 0) {
				toastr.error('Threshold value should be greater than zero.',
						'Error');
				return false;
			}
		} else {
			if (exceptionmodel.threshold_percent == 0) {
				toastr.error('Threshold value should be greater than zero.',
						'Error');
				return false;
			}
		}
		exceptionservice
				.updateExceptionRule(exceptionmodel)
				.then(
						function(data) {
							if (data.status) {
								toastr.success('Alert Rule updated successfully');

								$scope.loadData(exceptionmodel.exceptionRuleId);
								// $state.reload();

								$scope.isChange = false;
							} else {
								toastr.error(data.message,
										'Error');
							}

						},
						function(errResponse) {
							toastr
									.error(
											'Error while updating Alert rule. Please try again or contact administrator',
											'Error');
						});

	}
	$scope.editrule = true;
	$scope.setError = "";

	$scope.isChange = false;
	$scope.$watch('exceptionmodel', function(entity) {
		checkDataModified();
	}, true);
	
	$scope.$watch('threshold1', function(value) {
		checkDataModified();
	}, true);
	
	$scope.$watch('threshold2', function(value) {
		checkDataModified();
	}, true);

	function checkDataModified(){
		if (angular.equals($scope.exceptionmodel, $scope.oldModel) && angular.equals($scope.threshold1, $scope.threshold1_old) && angular.equals($scope.threshold2, $scope.threshold2_old)) {
			$scope.isChange = false;
		} else {
			if ($scope.role != 'view_only' || $scope.role != 'coverage_based') {
				$scope.isChange = true;
			}

		}
	}
};
