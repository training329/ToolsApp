/**
 * Created by ag52020 on 12/30/2015.
 */

'use strict';

/* Directives */

var AppDirectives = angular.module('AngularSpringApp.directives', []);

AppDirectives.directive('envName', ['CONFIG', function (CONFIG) {
	return {
    	restrict: 'E',
    	compile: function($element, $attr) {
        	if(CONFIG && CONFIG.envName && CONFIG.envName != "" && CONFIG.envName.indexOf("prod") == -1) {
        		$element.html('<div style="font-size: 13px; left: 300px;position: relative;top: 2px;" class="pull-left"><strong><span style="background-color: #d19929; color: black; font-family: arial,san-serif; padding: 5px;" >'+CONFIG.envName.toUpperCase()+'</span></strong></div>');
        	}
        },
 	}
}]);

AppDirectives.directive('fileUpload', function () {
    return {
        scope: true,        // create a new scope
        link: function (scope, el, attrs) {
            el.bind('change', function (event) {
                var files = event.target.files;
                // iterate files since 'multiple' may be specified on the
				// element
                for (var i = 0;i<files.length;i++) {
                    // emit event upward
                    scope.$emit("fileSelected", { file: files[i] });
                }                                       
            });
        }
    };
});
AppDirectives.directive('backButton',["$window", "utilService", function ($window, utilService) {
	  return {
	        restrict: "A",
	        scope : {
	        	allowNavigation:'='
        	},
	        link: function (scope, elem, attrs) {
	            elem.bind("click", function () {
	            	 if (scope.allowNavigation == null || scope.allowNavigation===true) {	     		 		
	        			 $window.history.back();
	     	        } else {
	     	        	utilService.confirmDialog('You have unsaved changes on this page. Do you want to leave this page?', 'Navigating Away', ['No', "Yes"])
	     	        	.then(function(){
	     	        		$window.history.go(-2); // Note with model dialog we have to go back -2 to navigate to previous state
						}, function() {
						  console.log("do nothing");
						})
	     	        }
	            });
	        }
	    };
}]);
