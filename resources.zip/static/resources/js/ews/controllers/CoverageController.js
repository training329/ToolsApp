/**
 * Added By Avinash
 */

var CoverageController = function($scope, $state, $location, $cookies,user,
		$rootScope, $http, $filter, blockUI, toastr, NgTableParams, authService) {

	// $scope.currentUser = $cookies.currentUser;
	$scope.coverageDetails = [];
	$scope.Searchterm = '';
	var result = user;//$cookies.getObject('Userinfo');
	$scope.currentUser = result.name;
	$scope.soeid = result.soeid;
	$scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;

	$scope.logout = function() {
		authService.logout().then(function(data) {
			$state.go('login');
		})
	}

	$scope.getcoverageDetails = function() {
		console.time("scope.getcoverageDetails: GET");
		$http
				.get('/ews/coverage/coverage.json')
				.success(function(data) {
					console.timeEnd("scope.getcoverageDetails: GET");
                    console.time("scope.getcoverageDetails: SCREEN");
					$scope.coverageDetails = data;
					$scope.tableParams.reload();
					console.timeEnd("scope.getcoverageDetails: SCREEN");
				})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting coverage details. Please try again or contact administrator',
											'Error');
						});
	}

	$scope.tableParams = new NgTableParams({
		page : 1,
		count : 25

	}, {
		total : $scope.coverageDetails.length,
		getData : function(params) {

			$scope.data = params.sorting() ? $filter('orderBy')(
					$scope.coverageDetails, params.orderBy())
					: $scope.coverageDetails;
			var filteredData = searchData($scope.data);
			$scope.data = filteredData.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData.length);
			return $scope.data;
		}
	});

	$scope.applyGlobalSearch = function(term) {
		$scope.tableParams.filter({
			$ : term
		});

	}

	var searchData = function(data) {
		if ($scope.Searchterm)
			return $filter('filter')(data, $scope.Searchterm);
		return data;
	}
	$scope.getcoverageDetails();
}