App.controller('SessionController', function($scope, Idle, authService, toastr) {

		// the user appears to have gone idle
        $scope.$on('IdleStart', function() {
          toastr.warning("You were idle too long. In case of no further activity, application will logged out in "+ Idle.getTimeout() +" secs." , "Warning!! You're idle");
          console.log('IdleStart.',new Date());
        });

		// the user has come back and is doing stuff. if you are warning them, you can use this to hide the dialog
        $scope.$on('IdleEnd', function() {
           console.log('#####IdleEnd.',new Date());
        });


		// the user has timed out (meaning idleDuration + timeout has passed without any activity)
        $scope.$on('IdleTimeout', function() {
          console.log('IdleTimeout.',new Date());
          authService.logout();
        });

		// sending server ping to keep the user's session alive
        $scope.$on('Keepalive', function() {
           console.log('Keepalive.');
        });

        $scope.reset = function() {
          Idle.watch();
        }

})
      