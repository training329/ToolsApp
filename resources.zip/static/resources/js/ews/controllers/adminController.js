/**
 * added by Avinash
 */
var adminController = function($scope, $location, $rootScope, $http, $filter,user,
		$cookies, $state, NgTableParams, toastr, adminService, authService, utilService) {

	$scope.EWSUsers = [];
	$scope.YesNo = [ 'NO', 'YES' ];
	var result = user;//$cookies.getObject('Userinfo');
	$scope.currentUser = result.name;
	$scope.soeid = result.soeid;
	$scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;
	$scope.Searchterm = '';

	$scope.logout = function() {
		authService.logout().then(function(data) {
			$state.go('login');
		})
	}

	$scope.getEWSUsers = function() {
		console.time("scope.getEWSUsers: GET");
		$http
				.get('/ews/adm/ewsusers.json')
				.success(function(data) {
					console.timeEnd("scope.getEWSUsers: GET");
		            console.time("scope.getEWSUsers: SCREEN");
					$scope.EWSUsers = data;
					$scope.tableParams.reload();
					console.timeEnd("scope.getEWSUsers: SCREEN");
				})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting coverage details. Please try again or contact administrator',
											'Error');
						});
	}
	
	$scope.exportUser = function() {
		$http({
            url: '/ews/adm/exportUsers',
            method: "POST",
            data: $scope.EWSUsers, 
            headers: {
               'Content-type': 'application/json'
            },
            responseType: 'arraybuffer'
        })
		.success(function(data, status, headers, config) {
			utilService.saveFile(new Blob([data], {type: "application/vnd.ms-excel"}), "Users.xls" );
           
		})
		.error(
			function(res) {
				toastr.error('Error while generating excel report. Please try again or contact administrator', 'Error');
		});
	}
	
	$scope.tableParams = new NgTableParams({
		page : 1,
		count : 15

	}, {
		total : $scope.EWSUsers.length,
		getData : function(params) {

			$scope.data = params.sorting() ? $filter('orderBy')(
					$scope.EWSUsers, params.orderBy()) : $scope.EWSUsers;
			var filteredData = searchData($scope.data);
			$scope.data = filteredData.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData.length);
			return $scope.data;
		}
	});
	$scope.getrole = function(value) {
		if (value == 'global_admin') {
			return 'GLOBAL ADMIN';
		} else if (value == 'admin') {
			return "ADMIN";
		} else if (value == 'coverage_based') {
			return "COVERAGE BASED";

		} else if (value == 'view_only') {
			return "VIEW ONLY";
		}
	}

	$scope.applyGlobalSearch = function(term) {
		$scope.tableParams.filter({
			$ : term
		});

	}

	var searchData = function(data) {
		if ($scope.Searchterm)
			return $filter('filter')(data, $scope.Searchterm);
		return data;
	}
	$scope.getEWSUsers();
};
var adminmanageController = function($scope, $cookies, $state, $location,
		$stateParams, $rootScope, $route, $http, $filter, $q, $state,user,
		NgTableParams, toastr, authService) {
	// $scope.currentUser = $cookies.currentUser;

	$('.checkbox').prop('indeterminate', true)
	$scope.user = $stateParams.id;
	$scope.UserCoverage = [];
	$scope.EWSUser = [];
	$scope.EWSCoverage = {};
	$scope.EWSCoverage.EWSUserRole = '';
	$scope.EWSCoverage.UserCoverage = [];
	$scope.EWSCoverage.ClientCoverage = [];
	$scope.EWSCoverage.EWSUser = {};
	$scope.isAllClientAccess=false;
	$scope.UserHistory = [];
	$scope.oldCoverage = [];
	$scope.coverageChanged=false;
	$scope.isAllClients = false;
	$scope.Permissions = {
		'all_clients' : true,
		'manage_rule' : false,
		'manage_alert_rule' : false,
		'add_admin' : true,
	};
	var result =user;// $cookies.getObject('Userinfo');
	$scope.currentUser = result.name;
	$scope.soeid = result.soeid;
	$scope.role = result.userRole.race_role;
    $scope.isCBAAccessible = result.isCBAAccessible;

	$scope.validateRole = function() {
		if ($scope.isChange) {
			if (angular.lowercase($scope.EWSCoverage.EWSUser.soeid) == $scope.soeid) {
				return true;
			} else {
				return false;
			}

		}
		return true;
	}
	$scope.validateRoleCase = function() {
		if (angular.lowercase($scope.EWSCoverage.EWSUser.soeid) == $scope.soeid)
			return true;

		return false;
	}
	$scope.logout = function() {
		authService.logout().then(function(data) {
			$state.go('login');
		})
	}
	$scope.getrole = function(value) {
		if (value == 'global_admin') {
			return 'GLOBAL ADMIN';
		} else if (value == 'admin') {
			return "ADMIN";
		} else if (value == 'coverage_based') {
			return "COVERAGE BASED";

		} else if (value == 'view_only') {
			return "VIEW ONLY";
		}
	}
	$scope.$watch('EWSCoverage.EWSUserRole', function(value) {
		switch (value) {

		case "global_admin":

			$scope.EWSCoverage.EWSUser.all_client = true;
			$scope.EWSCoverage.EWSUser.manage_alert = true;
			$scope.EWSCoverage.EWSUser.manage_alert_rule = true;
			$scope.EWSCoverage.EWSUser.add_admin = true;
			$scope.EWSCoverage.EWSUser.manage_coverage = true;

			break;
		case "admin":

			$scope.EWSCoverage.EWSUser.all_client = true;
			$scope.EWSCoverage.EWSUser.manage_alert = true;
			$scope.EWSCoverage.EWSUser.manage_alert_rule = true;
			$scope.EWSCoverage.EWSUser.add_admin = false;
			$scope.EWSCoverage.EWSUser.manage_coverage = true;

			break;
		case "coverage_based":
			if ($scope.EWSCoverage.EWSUser.race_role != 'coverage_based')
			{	$scope.EWSCoverage.EWSUser.all_client = false;
			}else{
			$scope.EWSCoverage.EWSUser.all_client=$scope.isAllClientAccess;
			}
			
			$scope.EWSCoverage.EWSUser.manage_alert = true;
			$scope.EWSCoverage.EWSUser.manage_alert_rule = false;
			$scope.EWSCoverage.EWSUser.add_admin = false;
			$scope.EWSCoverage.EWSUser.manage_coverage = false;

			break;
		case "view_only":
			$scope.EWSCoverage.EWSUser.all_client = true;
			$scope.EWSCoverage.EWSUser.manage_alert = false;
			$scope.EWSCoverage.EWSUser.manage_alert_rule = false;
			$scope.EWSCoverage.EWSUser.add_admin = false;
			$scope.EWSCoverage.EWSUser.manage_coverage = false;

			break;
		}
	});
	$scope.getUserCoverage = function() {
		console.time("scope.getUserCoverage: GET");
		$http
				.get('/ews/adm/getUserCoverage/' + $stateParams.id)
				.success(
						function(data) {
							console.timeEnd("scope.getUserCoverage: GET");
				            console.time("scope.getUserCoverage: SCREEN");

							// $scope.EWSCoverage.UserCoverage=data;

							$scope.EWSCoverage.UserCoverage = _.filter(data,
									function(item) {
										return item.source == 'AQUA'
									})
							$scope.EWSCoverage.ClientCoverage = _.filter(data,
									function(item) {
										return item.source == 'CRM'
									})
							$scope.oldCoverage = angular
									.copy($scope.EWSCoverage.UserCoverage);
							$scope.tableParams.reload();
							$scope.tableParams1.reload();
							console.timeEnd("scope.getUserCoverage: SCREEN");

						})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting user coverage details. Please try again or contact administrator',
											'Error');
						});
	}

	$scope.getClientCoverageList = function() {
		console.time("scope.getClientCoverageList: GET");
		$http
				.get('/ews/adm/getClientCoverageList/')
				.success(function(data) {
					console.timeEnd("scope.getClientCoverageList: GET");
		            console.time("scope.getClientCoverageList: SCREEN");

					$scope.ClientCoverageList = data;
					console.timeEnd("scope.getClientCoverageList: SCREEN");
				})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting user coverage details. Please try again or contact administrator',
											'Error');
						});
	}
	
	$scope.getuserHistoryCoverageList = function(soeid,operation,created_time) {
		console.time("scope.getuserHistoryCoverageList: GET");
		objrequest={
				soeid:soeid,
				operation:operation,
				created_time:created_time
		}
		$http
				.post('/ews/adm/UserCoverageHistory.json',objrequest)
				.success(function(data) {
					console.timeEnd("scope.getuserHistoryCoverageList: GET");
		            console.time("scope.getuserHistoryCoverageList: SCREEN");

					$scope.usercoveragehistory = data;
					$('#myModal').modal('show'); 
		            console.timeEnd("scope.getuserHistoryCoverageList: SCREEN");
				})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting user coverage details. Please try again or contact administrator',
											'Error');
						});
	}


	$scope.getEWSUser = function() {
		console.time("scope.getEWSUser: GET");
		$http
				.get('/ews/adm/getEWSUser/' + $stateParams.id)
				.success(
						function(data) {
							console.timeEnd("scope.getEWSUser: GET");
				            console.time("scope.getEWSUser: SCREEN");
							if (data) {
								$scope.EWSCoverage.EWSUser = data;
								$scope.EWSCoverage.EWSUserRole = $scope.EWSCoverage.EWSUser.race_role;
								$scope.isAllClients = $scope.EWSCoverage.EWSUser.all_client;
								$scope.isAllClientAccess=angular.copy($scope.EWSCoverage.EWSUser.all_client);
								$scope.oldRole = $scope.EWSCoverage.EWSUser.race_role;
								isChange = false;

								$scope.getUserHistory();
							}
							console.timeEnd("scope.getEWSUser: SCREEN");
						})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting EWS User details. Please try again or contact administrator',
											'Error');
						});
	}

	$scope.getUserHistory = function() {
		console.time("scope.getUserHistory: GET");
		$http
				.get('/ews/adm/getUserHistory/' + $stateParams.id)
				.success(function(data) {
					console.timeEnd("scope.getUserHistory: GET");
		            console.time("scope.getUserHistory: SCREEN");

					if (data) {
						$scope.UserHistory = data;
						$scope.tableParams3.reload();
					}
		            console.timeEnd("scope.getUserHistory: SCREEN");

				})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting EWS User history details. Please try again or contact administrator',
											'Error');
						});
	}
	$scope.getEWSUser();
	// $scope.getClientCoverageList();
	$scope.submitUserCoverage = function(EWSUserCoverage) {
		console.time("scope.submitUserCoverage: GET");
		var gpnum = '';
		if ($scope.EWSCoverage.EWSUserRole === 'coverage_based') {
			gpnum = _.pluck($scope.EWSCoverage.UserCoverage, 'gpnum').join(",");
		}
		$http
				.post(
						'/ews/adm/UpdateUserRole/',
						{
							'soeid' : $scope.EWSCoverage.EWSUser.soeid,
							'role' : EWSUserCoverage.EWSUserRole,
							'all_client' : $scope.EWSCoverage.EWSUser.all_client == true ? 1
									: 0,
							'gpnum' : gpnum,
							'updatedby' : ''
						})
				.success(function(data) {
					console.timeEnd("scope.submitUserCoverage: GET");
		            console.time("scope.submitUserCoverage: SCREEN");
					$scope.getUserCoverage();
					$scope.getEWSUser();
					$scope.isChange = false;
					$scope.coverageChanged=false;
					toastr.success('Client coverage updated successfully');
					console.timeEnd("scope.submitUserCoverage: SCREEN");
				})
				.error(
						function(res) {
							toastr
									.error(
											'Error while getting updating User Role/Coverage. Please try again or contact administrator',
											'Error');
						});

	};

	$scope.addCoverage = function(coverage) {
		if (coverage) {
			//$('#coveragetabs a[href="#crm"]').tab('show');
			$('a[data-target=#crm]').trigger('click');
			if ($scope.EWSCoverage.EWSUser.all_client == false) {
				var _coverage = _.findWhere($scope.EWSCoverage.UserCoverage, {
					'gpnum' : coverage[0].value
				});

				if (_coverage) {
					toastr.error('Coverage client is already added', 'Error');
				} else {
					var _coverageCRM = _.findWhere(
							$scope.EWSCoverage.ClientCoverage, {
								'gpnum' : coverage[0].value
							});
					if (_coverageCRM) {
						toastr.error('Coverage client is already added', 'Error');
					} else {
						var _coverageName = _.findWhere(
								$scope.ClientCoverageList, {
									'value' : coverage[0].value
								});

						$scope.EWSCoverage.UserCoverage.push({
							'gpnum' : coverage[0].value,
							'gpname' : _coverageName.text,
							'source' : 'AQUA'
						});
						$scope.tableParams.reload();
					}
				}

			}
		}
	}
	$scope.removeCoverage = function(coverage) {
		if (coverage) {
			$scope.EWSCoverage.UserCoverage = _.reject(
					$scope.EWSCoverage.UserCoverage, function(d) {
						return d.gpnum === coverage;
					});
		}
		$scope.tableParams.reload();
	}
	$scope.tableParams = new NgTableParams({
		page : 1,
		count : 7

	}, {
		total : $scope.EWSCoverage.UserCoverage.length,
		getData : function(params) {

			$scope.data = params.sorting() ? $filter('orderBy')(
					$scope.EWSCoverage.UserCoverage, params.orderBy())
					: $scope.EWSCoverage.UserCoverage;
			var filteredData = searchData($scope.data);
			$scope.data = filteredData.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData.length);
			return $scope.data;
		}
	});

	$scope.tableParams1 = new NgTableParams({
		page : 1,
		count : 7

	}, {
		total : $scope.EWSCoverage.ClientCoverage.length,
		getData : function(params) {

			$scope.data1 = params.sorting() ? $filter('orderBy')(
					$scope.EWSCoverage.ClientCoverage, params.orderBy())
					: $scope.EWSCoverage.ClientCoverage;
			var filteredData1 = searchData($scope.data1);
			$scope.data1 = filteredData1.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData1.length);
			return $scope.data1;
		}
	});
	$scope.tableParams3 = new NgTableParams({
		page : 1,
		count : 5,
		sorting : {
			id : "desc"
		}

	}, {
		total : $scope.UserHistory.length,
		getData : function(params) {

			$scope.data3 = params.sorting() ? $filter('orderBy')(
					$scope.UserHistory, params.orderBy()) : $scope.UserHistory;
			var filteredData3 = searchData($scope.data3);
			$scope.data3 = filteredData3.slice((params.page() - 1)
					* params.count(), params.page() * params.count());
			params.total(filteredData3.length);
			return $scope.data3;
		}
	});
	$scope.applyGlobalSearch = function(term) {
		$scope.tableParams.filter({
			$ : term
		});

	}

	var searchData = function(data) {
		if ($scope.Searchterm)
			return $filter('filter')(data, $scope.Searchterm);
		return data;
	}

	$scope.showtable = function() {

		if ($scope.EWSCoverage.EWSUserRole == 'coverage_based'
				&& $scope.EWSCoverage.EWSUser.all_client != true)
			return true;

		return false;
	}
	$scope.$watch('EWSCoverage.EWSUserRole', function(entity) {
		if(entity){
		if ($scope.EWSCoverage.EWSUserRole === 'coverage_based') {
			$scope.getUserCoverage();
			$scope.getClientCoverageList();
		}

		if (angular.equals(entity, $scope.oldRole)) {
			$scope.isChange = false;
			$scope.coverageChanged=false;
		} else {
			$scope.isChange = true;
			$scope.coverageChanged=true;
		}
		}
	}, true);

	$scope.$watch('EWSCoverage.UserCoverage', function(entity) {
		if(entity){
		if (angular.equals(entity, $scope.oldCoverage)) {
			if(!$scope.isAllClientAccess)
			$scope.isChange = false;
		} else {
			$scope.isChange = true;
			
		}
		}
	}, true);

	$scope.$watch('EWSCoverage.EWSUser.all_client', function(isall) {
//		if (isall) {
//			// $scope.getUserCoverage();
//			$scope.EWSCoverage.UserCoverage = [];
//
//		} else {
//
//			$scope.EWSCoverage.UserCoverage = angular.copy($scope.oldCoverage);
//		}
		if(isall!=undefined){
		if (angular.equals(isall, $scope.isAllClients)) {
			$scope.isChange = false;
			if ($scope.coverageChanged) {
				$scope.isChange = true;
			}
		} else {
			$scope.isChange = true;
		}
		}

	}, true);
	$scope.itemLabelFormatter = function (item) {
	   return (item.value + ' ' +':' + ' ' +item.text );

	}
};
