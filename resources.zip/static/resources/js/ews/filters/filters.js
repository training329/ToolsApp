/**
 * Created by ag52020 on 12/30/2015.
 */
'use strict';

/* Filters */

var AppFilters = angular.module('AngularSpringApp.filters', []);

App.filter('buildInfo', ['CONFIG', function (CONFIG) {
    return function (text) {
    	if(CONFIG.buildVersion && CONFIG.buildVersion != ""){
    		return String(text).replace(/\%VERSION\%/mg,  "Build Version : "+CONFIG.buildVersion);
    	}
    	return "";
    };  
}]);

AppFilters.filter('split', ['input', function (input) {
    return function (input) {
    	return input.split(',');
    }
}]);

AppFilters.filter('encodeURIComponent', function() {
    return function(input) {
        if(input) {
            return window.encodeURIComponent(input); 
        }
        return "";
    }
});
AppFilters.filter('dateformat',[function (input) {
	return function (input) {
		if(input!=null){
    	return input.toString().substring(4,6)+'/'+input.toString().substring(6, 8)+'/'+input.toString().substring(0, 4);
		}
	 	  return input;
	 
    }
}]);

AppFilters.filter('emptyFilter',[function (input) {
	return function (input) {
		if(input==null || input==''){
    	return '-';
		}
	 	  return input;
	 
    }
}]);

AppFilters.filter('date1',[function (input) {
	return function (input) {
		if(input!=null){
    	return input.substring(5,7)+'/'+input.substring(7, 9)+'/'+input.substring(0, 3);
		}
	 	  return input;
	 
    }
}]);

AppFilters.filter('yesno',[function (input) {
	return function(input) {
        return input ? 'YES' : 'NO';
    }
}]);

//Change date from MM/DD/YYYY to YYYYMMDD
AppFilters.filter('DateToNumber',[function (input) {
	return function(input) {
        var splitted=input.split("-");
        return splitted[2]+splitted[0]+splitted[1];
    }
}]);
AppFilters.filter('regional', [ function(val1,val2) {
	
	return function(val1,val2) {
		if (val2 == '3') {
			var filtered = _(val1).filter(function(item) {
			     return item.text !== 'GLOBAL'			    
			});
			 
		     return filtered;
		}
		return val1;
	}
} ]);


